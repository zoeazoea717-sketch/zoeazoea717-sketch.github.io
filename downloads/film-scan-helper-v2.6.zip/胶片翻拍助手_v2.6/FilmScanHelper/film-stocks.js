/*
 * 主流 135 胶卷（2026 年在售为主；括号内为中文名，仅用于菜单显示）
 * 片边文字只用英文名（Jura 字体不含中文）
 */
(function (root) {
  "use strict";
  const FILM_STOCKS = [
    { maker: "Kodak", cn: "柯达", models: [
      "Tri-X 400", "Ektapan 100", "Ektapan 400", "Ektapan P3200", "T-Max 100", "T-Max 400", "T-Max P3200", "Double-X 5222",
      "Portra 160", "Portra 400", "Portra 800", "Ektar 100", "Gold 200", "UltraMax 400", "ColorPlus 200",
      "Kodacolor 100", "Kodacolor 200", "Ektacolor Pro 400", "Ektacolor Pro 800", "Ektachrome E100"
    ] },
    { maker: "Ilford", cn: "依尔福", models: [
      "HP5 Plus 400", "FP4 Plus 125", "Delta 100", "Delta 400", "Delta 3200", "Pan F Plus 50", "XP2 Super 400", "SFX 200", "Ortho Plus 80"
    ] },
    { maker: "Kentmere", cn: "肯特美", models: ["Pan 100", "Pan 200", "Pan 400"] },
    { maker: "Harman", cn: "哈曼", models: ["Phoenix 200", "Phoenix II 200"] },
    { maker: "Fujifilm", cn: "富士", models: [
      "Acros II 100", "Fujicolor 200", "Fujicolor 400", "Superia X-TRA 400", "C200", "Provia 100F", "Velvia 50", "Velvia 100"
    ] },
    { maker: "Lucky", cn: "乐凯", models: ["SHD 100", "SHD 400", "Shadow 100", "C200", "C400"] },
    { maker: "Shanghai", cn: "上海", models: ["GP3 100", "GP3 400", "Shenguang 400"] },
    { maker: "Foma", cn: "福马", models: ["Fomapan 100", "Fomapan 200", "Fomapan 400", "Retropan 320"] },
    { maker: "Rollei", cn: "禄来", models: ["RPX 25", "RPX 100", "RPX 400", "Retro 80S", "Retro 400S", "Superpan 200", "Infrared 400", "Ortho 25"] },
    { maker: "Adox", cn: "", models: ["CHS 100 II", "HR-50", "Silvermax 100", "Scala 50"] },
    { maker: "AgfaPhoto", cn: "爱克发", models: ["APX 100", "APX 400"] },
    { maker: "Lomography", cn: "乐魔", models: [
      "Earl Grey 100", "Lady Grey 400", "Berlin Kino 400", "Potsdam Kino 100",
      "Color Negative 100", "Color Negative 400", "Color Negative 800", "LomoChrome Purple", "LomoChrome Metropolis", "LomoChrome Color '92"
    ] },
    { maker: "CineStill", cn: "", models: ["BwXX", "50D", "400D", "800T"] },
    { maker: "Ferrania", cn: "", models: ["P30", "P33"] },
    { maker: "Bergger", cn: "", models: ["Pancro 400"] },
    { maker: "ORWO", cn: "", models: ["N74 Plus", "UN54", "Wolfen NC500"] }
  ];

  const api = { FILM_STOCKS };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.FilmStocks = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
