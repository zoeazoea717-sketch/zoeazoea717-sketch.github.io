/*
 * ps-ops.js — Photoshop 操作封装（batchPlay / DOM）
 * 所有函数都必须在 core.executeAsModal 内调用。
 */
"use strict";

const { app, action, constants, imaging } = require("photoshop");

const LAYER = {
  base: "负片",
  bw: "黑白",
  invert: "反色",
  levels: "反色定标",
  tone: "影调"
};

async function bp(descriptors) {
  const list = Array.isArray(descriptors) ? descriptors : [descriptors];
  const res = await action.batchPlay(list, { synchronousExecution: false, modalBehavior: "execute" });
  for (const r of res) {
    if (r && r._obj === "error") throw new Error(r.message || ("Photoshop 错误 " + r.result));
  }
  return res;
}

const ordinalLayer = () => [{ _ref: "layer", _enum: "ordinal", _value: "targetEnum" }];
const ordinalDoc = () => [{ _ref: "document", _enum: "ordinal", _value: "targetEnum" }];

// ---------- 打开 ----------
async function openAsSmartObject(token) {
  await bp({
    _obj: "open",
    null: { _path: token, _kind: "local" },
    smartObject: true,
    _options: { dialogOptions: "dontDisplay" }
  });
  return app.activeDocument;
}

async function openPlain(token) {
  await bp({ _obj: "open", null: { _path: token, _kind: "local" }, _options: { dialogOptions: "dontDisplay" } });
  return app.activeDocument;
}

async function convertDepth(bits) {
  try { await bp({ _obj: "convertMode", depth: bits, merge: false }); } catch (e) { /* 已是该位深或不支持 */ }
}

// ---------- 像素 ----------
async function readComposite(doc, longSide) {
  const W = doc.width, H = doc.height;
  const s = Math.min(1, longSide / Math.max(W, H));
  const tw = Math.max(16, Math.round(W * s)), th = Math.max(16, Math.round(H * s));
  const res = await imaging.getPixels({
    documentID: doc.id,
    targetSize: { width: tw, height: th },
    colorSpace: "RGB"
  });
  const img = res.imageData;
  try {
    const data = await img.getData();
    const cs = img.componentSize;
    const maxValue = cs === 16 ? 32768 : cs === 32 ? 1 : 255;
    return { data, width: img.width, height: img.height, channels: img.components, maxValue, scaleX: W / img.width, scaleY: H / img.height };
  } finally {
    img.dispose();
  }
}

// ---------- 图层 ----------
function findLayer(doc, name) {
  const walk = (layers) => {
    for (const l of layers) {
      if (l.name === name || l.name.indexOf(name + " ") === 0) return l;
      if (l.layers && l.layers.length) { const f = walk(l.layers); if (f) return f; }
    }
    return null;
  };
  return walk(doc.layers);
}

async function selectLayer(layer) {
  await bp({ _obj: "select", _target: [{ _ref: "layer", _id: layer.id }], makeVisible: false });
}

async function convertActiveToSmartObject() {
  await bp({ _obj: "newPlacedLayer" });
}

async function rotateActiveLayer(deg) {
  if (Math.abs(deg) < 0.005) return;
  await bp({
    _obj: "transform",
    _target: ordinalLayer(),
    freeTransformCenterState: { _enum: "quadCenterState", _value: "QCSAverage" },
    offset: { _obj: "offset", horizontal: { _unit: "pixelsUnit", _value: 0 }, vertical: { _unit: "pixelsUnit", _value: 0 } },
    angle: { _unit: "angleUnit", _value: deg },
    interfaceIconFrameDimmed: { _enum: "interpolationType", _value: "bicubicAutomatic" }
  });
}

async function revealAll() {
  try { await bp({ _obj: "revealAll" }); } catch (e) { /* 无需显示 */ }
}

async function cropDoc(doc, r) {
  const rect = { left: Math.round(r.left), top: Math.round(r.top), right: Math.round(r.right), bottom: Math.round(r.bottom) };
  try {
    await doc.crop(rect);
  } catch (e) {
    await bp({
      _obj: "crop",
      to: {
        _obj: "rectangle",
        top: { _unit: "pixelsUnit", _value: rect.top },
        left: { _unit: "pixelsUnit", _value: rect.left },
        bottom: { _unit: "pixelsUnit", _value: rect.bottom },
        right: { _unit: "pixelsUnit", _value: rect.right }
      },
      angle: { _unit: "angleUnit", _value: 0 },
      delete: false,
      AutoFillMethod: 1,
      cropFillMode: { _enum: "cropFillMode", _value: "defaultFill" },
      cropAspectRatioModeKey: { _enum: "cropAspectRatioModeClass", _value: "pureAspectRatio" },
      constrainProportions: false
    });
  }
}

async function flipCanvasHorizontal() {
  await bp({ _obj: "flip", _target: ordinalDoc(), axis: { _enum: "orientation", _value: "horizontal" } });
}

async function rotateCanvas(deg) {
  await bp({ _obj: "rotateEventEnum", _target: ordinalDoc(), angle: { _unit: "angleUnit", _value: deg } });
}

async function getSelectionBounds() {
  const r = await bp({ _obj: "get", _target: [{ _property: "selection" }, { _ref: "document", _enum: "ordinal", _value: "targetEnum" }] });
  const s = r[0] && r[0].selection;
  if (!s || s.top === undefined) return null;
  const v = (x) => (typeof x === "number" ? x : x._value);
  return { top: v(s.top), left: v(s.left), bottom: v(s.bottom), right: v(s.right) };
}

async function deselect() {
  try { await bp({ _obj: "set", _target: [{ _ref: "channel", _property: "selection" }], to: { _enum: "ordinal", _value: "none" } }); } catch (e) { /* 无选区 */ }
}

// ---------- 调整图层 ----------
function levelsDesc(lv) {
  return {
    _obj: "levels",
    presetKind: { _enum: "presetKindType", _value: "presetKindCustom" },
    adjustment: [{
      _obj: "levelsAdjustment",
      channel: { _ref: "channel", _enum: "channel", _value: "composite" },
      input: [Math.round(lv.inBlack), Math.round(lv.inWhite)],
      gamma: Math.max(0.1, Math.min(9.99, lv.gamma))
    }]
  };
}

function curvesDesc(points) {
  return {
    _obj: "curves",
    presetKind: { _enum: "presetKindType", _value: "presetKindCustom" },
    adjustment: [{
      _obj: "curvesAdjustment",
      channel: { _ref: "channel", _enum: "channel", _value: "composite" },
      curve: points.map(([x, y]) => ({ _obj: "paint", horizontal: x, vertical: y }))
    }]
  };
}

const bwDesc = () => ({
  _obj: "blackAndWhite",
  presetKind: { _enum: "presetKindType", _value: "presetKindDefault" },
  red: 40, yellow: 60, grain: 40, cyan: 60, blue: 20, magenta: 80,
  useTint: false
});

async function makeAdjustment(doc, typeDesc, name) {
  try {
    await bp({
      _obj: "make",
      _target: [{ _ref: "adjustmentLayer" }],
      using: { _obj: "adjustmentLayer", type: typeDesc }
    });
  } catch (e) {
    // 退路：先用默认参数建层，再写入参数
    const minimal = { _obj: typeDesc._obj };
    if (typeDesc.presetKind) minimal.presetKind = { _enum: "presetKindType", _value: "presetKindDefault" };
    await bp({ _obj: "make", _target: [{ _ref: "adjustmentLayer" }], using: { _obj: "adjustmentLayer", type: minimal } });
    if (typeDesc.adjustment) {
      await bp({ _obj: "set", _target: [{ _ref: "adjustmentLayer", _enum: "ordinal", _value: "targetEnum" }], to: typeDesc });
    }
  }
  const layer = doc.activeLayers[0];
  if (layer && name) layer.name = name;
  return layer;
}

async function setAdjustment(layer, typeDesc, name) {
  await selectLayer(layer);
  await bp({ _obj: "set", _target: [{ _ref: "adjustmentLayer", _enum: "ordinal", _value: "targetEnum" }], to: typeDesc });
  if (name) layer.name = name;
}

// ---------- 保存 / 导出 ----------
async function savePsd(doc, fileEntry, maxCompat) {
  await doc.saveAs.psd(fileEntry, { embedColorProfile: true, maximizeCompatibility: maxCompat !== false }, false);
}

// onSrgb(dup)：在拼合、8 位、sRGB 的副本上执行（用于取画框/预览图像素）
async function exportJpeg(doc, fileEntry, quality, onSrgb) {
  const srcId = doc.id;
  const dup = await doc.duplicate(doc.title + "_jpeg");
  try {
    await dup.flatten();
    await convertDepth(8);
    try { await dup.convertProfile("sRGB IEC61966-2.1", constants.Intent.RELATIVECOLORIMETRIC, true, false); } catch (e) { /* 保留原色彩空间 */ }
    if (fileEntry) await dup.saveAs.jpg(fileEntry, { quality: quality || 11, embedColorProfile: true }, true);
    if (onSrgb) await onSrgb(dup);
  } finally {
    await dup.closeWithoutSaving();
  }
  const back = app.documents.find((d) => d.id === srcId);
  if (back) app.activeDocument = back;
}

// ---------- 像素读写（画框 / 预览图） ----------
async function pixelsOf(opts) {
  const res = await imaging.getPixels(Object.assign({ colorSpace: "RGB" }, opts));
  const img = res.imageData;
  try {
    let data = await img.getData();
    const comps = img.components, cs = img.componentSize;
    if (cs === 16 || cs === 32) {
      const k = cs === 16 ? 255 / 32768 : 255;
      const d8 = new Uint8Array(data.length);
      for (let i = 0; i < data.length; i++) d8[i] = Math.max(0, Math.min(255, Math.round(data[i] * k)));
      data = d8;
    }
    return { w: img.width, h: img.height, data, channels: comps, sourceBounds: res.sourceBounds };
  } finally {
    img.dispose();
  }
}

async function readFullRGB(doc) {
  return pixelsOf({ documentID: doc.id });
}

// 居中裁成 cellW:cellH 后缩到 cellW×cellH
async function readThumb(doc, cellW, cellH) {
  const W = doc.width, H = doc.height, r = cellW / cellH;
  let l = 0, t = 0, w = W, h = H;
  if (W / H > r) { w = Math.round(H * r); l = Math.round((W - w) / 2); }
  else { h = Math.round(W / r); t = Math.round((H - h) / 2); }
  return pixelsOf({ documentID: doc.id, sourceBounds: { left: l, top: t, right: l + w, bottom: t + h }, targetSize: { width: cellW, height: cellH } });
}

// 把 RGB 缓冲写进新文档并存为 JPEG
async function saveRgbAsJpeg(buf, fileEntry, quality, name) {
  const prevId = app.activeDocument ? app.activeDocument.id : null;
  const doc = await app.documents.add({
    name: name || "film_frame", width: buf.w, height: buf.h, resolution: 300,
    mode: constants.NewDocumentMode.RGB, fill: constants.DocumentFill.WHITE, profile: "sRGB IEC61966-2.1"
  });
  try {
    const img = await imaging.createImageDataFromBuffer(buf.data, {
      width: buf.w, height: buf.h, components: 3, chunky: true, colorSpace: "RGB", colorProfile: "sRGB IEC61966-2.1"
    });
    try {
      let layerId = doc.layers[0].id;
      try {
        await imaging.putPixels({ documentID: doc.id, layerID: layerId, imageData: img, replace: true, targetBounds: { left: 0, top: 0 } });
      } catch (e) {
        const l = await doc.createLayer({ name: "frame" });
        await imaging.putPixels({ documentID: doc.id, layerID: l.id, imageData: img, replace: true, targetBounds: { left: 0, top: 0 } });
      }
    } finally {
      img.dispose();
    }
    await doc.saveAs.jpg(fileEntry, { quality: quality || 11, embedColorProfile: true }, true);
  } finally {
    await doc.closeWithoutSaving();
  }
  const back = prevId != null ? app.documents.find((d) => d.id === prevId) : null;
  if (back) app.activeDocument = back;
}

// ---------- 字形图集：用已安装字体在临时文档里渲染每个字符 ----------
function findFont(preferredPS, family, style) {
  try {
    const fonts = app.fonts;
    const n = fonts.length;
    let byFamily = null;
    for (let i = 0; i < n; i++) {
      const f = fonts[i];
      if (f.postScriptName === preferredPS) return preferredPS;
      if (!byFamily && f.family === family && String(f.style).toLowerCase() === style.toLowerCase()) byFamily = f.postScriptName;
    }
    return byFamily;
  } catch (e) {
    return preferredPS; // 无法枚举时直接尝试
  }
}

// 在候选字体里找第一个已安装的（按 PostScript 名）
function findFirstFont(candidates) {
  try {
    const fonts = app.fonts, n = fonts.length, have = new Set();
    for (let i = 0; i < n; i++) { try { have.add(fonts[i].postScriptName); } catch (e) { /* skip */ } }
    for (const c of candidates) if (have.has(c)) return c;
    return null;
  } catch (e) {
    return candidates[0];
  }
}

async function buildAtlas(chars, fontName, em) {
  const doc = await app.documents.add({
    name: "_film_atlas", width: 1600, height: 600, resolution: 72,
    mode: constants.NewDocumentMode.RGB, fill: constants.DocumentFill.WHITE
  });
  const X = 300, Y = 420;
  const mkText = (txt) => doc.createTextLayer({ contents: txt, fontName, fontSize: em, position: { x: X, y: Y } });
  const widthOf = async (txt) => {
    const l = await mkText(txt);
    const b = l.bounds;
    await l.delete();
    return b.right - b.left;
  };
  try {
    const hh = await widthOf("HH");
    const glyphs = {};
    for (const ch of chars) {
      const layer = await mkText(ch);
      let g = { w: 0, h: 0, a: new Uint8Array(0), lsb: 0, top: 0, adv: 0 };
      try {
        const px = await pixelsOf({ documentID: doc.id, layerID: layer.id });
        const sb = px.sourceBounds || layer.bounds;
        const n = px.w * px.h, a = new Uint8Array(n);
        if (px.channels === 4) for (let i = 0; i < n; i++) a[i] = px.data[i * 4 + 3];
        else for (let i = 0; i < n; i++) a[i] = 255 - px.data[i * px.channels];
        g = { w: px.w, h: px.h, a, lsb: sb.left - X, top: sb.top - Y, adv: 0 };
      } finally {
        await layer.delete();
      }
      g.adv = Math.max(1, (await widthOf("H" + ch + "H")) - hh);
      glyphs[ch] = g;
    }
    glyphs[" "] = { w: 0, h: 0, a: new Uint8Array(0), lsb: 0, top: 0, adv: Math.max(1, (await widthOf("H H")) - hh) };
    return { em, font: fontName, glyphs };
  } finally {
    await doc.closeWithoutSaving();
  }
}

module.exports = {
  LAYER, bp, openAsSmartObject, openPlain, convertDepth, readComposite, findLayer, selectLayer,
  convertActiveToSmartObject, rotateActiveLayer, revealAll, cropDoc, flipCanvasHorizontal, rotateCanvas,
  getSelectionBounds, deselect, levelsDesc, curvesDesc, bwDesc, makeAdjustment, setAdjustment, savePsd, exportJpeg,
  readFullRGB, readThumb, saveRgbAsJpeg, findFont, findFirstFont, buildAtlas
};
