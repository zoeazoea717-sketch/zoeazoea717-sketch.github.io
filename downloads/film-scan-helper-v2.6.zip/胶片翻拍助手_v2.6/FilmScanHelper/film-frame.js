/*
 * film-frame.js — 胶片画框（135）与整卷预览图（印样）合成
 * 纯 JS，Photoshop UXP 与 Node 共用。所有绘制在 RGB 8 位缓冲区里完成，
 * 文字使用“字形图集”（atlas）：由 Photoshop 用 Jura Bold 渲染后取出的灰度字形。
 *
 * atlas = { em: 渲染字号(px), glyphs: { ch: { w, h, a: Uint8Array(alpha), lsb, top, adv } } }
 *   lsb: 字形左边相对笔位的偏移；top: 字形顶部相对基线的偏移（负数在基线上方）；adv: 步进宽度
 */
(function (root) {
  "use strict";

  const STYLE = {
    strip: [10, 10, 9],         // 片基黑
    base: [28, 27, 26],         // 预览图底板：深炭灰
    hole: [238, 234, 226],      // 齿孔：白
    sheetHole: [238, 234, 226], // 预览图齿孔
    edge: [232, 150, 62],       // 所有文字：琥珀橙
    note: [232, 150, 62],       // 预览图右下角小字（同为橙色）
    empty: [10, 10, 9]          // 空白帧
  };

  // 整卷预览图的两套底板 + 两种文字颜色（底板上的右下角文字与签名；片条上的字始终是橙色）
  const SHEET_THEMES = {
    dark: {  // 深色（暗房哑黑）
      base: [40, 38, 35], baseEdge: [13, 12, 11], grain: 5, mottle: 3,
      sheetHole: [238, 234, 226], shadow: { a: 0.55, r: 22, dy: 6 },
      notes: { orange: [232, 150, 62], black: [232, 150, 62] }   // 深底上黑字看不见，固定橙色
    },
    light: { // 浅色（看片灯箱）
      base: [250, 249, 245], baseEdge: [208, 207, 201], grain: 2.5, mottle: 2,
      sheetHole: [252, 251, 247], shadow: { a: 0.28, r: 26, dy: 8 },
      notes: { orange: [212, 116, 38], black: [34, 32, 30] }
    },
    white: { // 纯白：干净的白底，无渐变、无颗粒、无投影
      base: [255, 255, 255], baseEdge: [255, 255, 255], grain: 0, mottle: 0,
      sheetHole: [255, 255, 255], shadow: null,
      notes: { orange: [212, 116, 38], black: [26, 25, 24] }
    }
  };
  function sheetStyle(bg, textColor) {
    const t = SHEET_THEMES[bg] || SHEET_THEMES.dark;
    const st = Object.assign({}, t);
    st.note = t.notes[textColor] || t.notes.orange;
    delete st.notes;
    return st;
  }

  // ---------- 缓冲区 ----------
  function makeBuf(w, h, rgb) {
    const data = new Uint8Array(w * h * 3);
    if (rgb) fillRect({ w, h, data }, 0, 0, w, h, rgb);
    return { w, h, data };
  }

  function fillRect(buf, x0, y0, x1, y1, rgb) {
    x0 = Math.max(0, Math.floor(x0)); y0 = Math.max(0, Math.floor(y0));
    x1 = Math.min(buf.w, Math.ceil(x1)); y1 = Math.min(buf.h, Math.ceil(y1));
    if (x1 <= x0 || y1 <= y0) return;
    const d = buf.data, rowLen = (x1 - x0) * 3;
    // 先填一行，再复制
    let o = (y0 * buf.w + x0) * 3;
    for (let i = 0; i < rowLen; i += 3) { d[o + i] = rgb[0]; d[o + i + 1] = rgb[1]; d[o + i + 2] = rgb[2]; }
    const first = d.subarray(o, o + rowLen);
    for (let y = y0 + 1; y < y1; y++) d.set(first, (y * buf.w + x0) * 3);
  }

  function blend(d, o, rgb, a) {
    if (a <= 0) return;
    if (a >= 1) { d[o] = rgb[0]; d[o + 1] = rgb[1]; d[o + 2] = rgb[2]; return; }
    d[o] += (rgb[0] - d[o]) * a; d[o + 1] += (rgb[1] - d[o + 1]) * a; d[o + 2] += (rgb[2] - d[o + 2]) * a;
  }

  // 抗锯齿圆角矩形（有符号距离）
  function fillRoundRect(buf, x, y, w, h, r, rgb) {
    r = Math.min(r, w / 2, h / 2);
    const xa = Math.max(0, Math.floor(x)), ya = Math.max(0, Math.floor(y));
    const xb = Math.min(buf.w, Math.ceil(x + w)), yb = Math.min(buf.h, Math.ceil(y + h));
    const cx = x + w / 2, cy = y + h / 2, hx = w / 2 - r, hy = h / 2 - r;
    const d = buf.data;
    for (let py = ya; py < yb; py++) {
      const qy = Math.abs(py + 0.5 - cy) - hy;
      for (let px = xa; px < xb; px++) {
        const qx = Math.abs(px + 0.5 - cx) - hx;
        const ox = Math.max(qx, 0), oy = Math.max(qy, 0);
        const sd = Math.sqrt(ox * ox + oy * oy) + Math.min(Math.max(qx, qy), 0) - r;
        const a = 0.5 - sd;
        if (a > 0) blend(d, (py * buf.w + px) * 3, rgb, a > 1 ? 1 : a);
      }
    }
  }

  // 向右的小三角箭头（Jura 无箭头字形）
  function fillArrow(buf, x, yMid, len, thick, rgb) {
    const shaft = len * 0.62, headH = thick * 2.6;
    fillRect(buf, x, yMid - thick / 2, x + shaft, yMid + thick / 2, rgb);
    const hx0 = x + shaft - thick * 0.2, hx1 = x + len;
    for (let py = Math.floor(yMid - headH / 2); py <= Math.ceil(yMid + headH / 2); py++) {
      const t = 1 - Math.abs(py + 0.5 - yMid) / (headH / 2);
      if (t <= 0) continue;
      const xe = hx0 + (hx1 - hx0) * t;
      for (let px = Math.floor(hx0); px < Math.ceil(xe); px++) {
        if (px < 0 || px >= buf.w || py < 0 || py >= buf.h) continue;
        const cov = Math.min(1, xe - px);
        blend(buf.data, (py * buf.w + px) * 3, rgb, cov);
      }
    }
  }

  function blit(buf, src, dx, dy) {
    // src: {w,h,data,channels(3|4)}
    const ch = src.channels || 3;
    for (let y = 0; y < src.h; y++) {
      const ty = dy + y;
      if (ty < 0 || ty >= buf.h) continue;
      let so = y * src.w * ch, to = (ty * buf.w + dx) * 3;
      if (ch === 3 && dx >= 0 && dx + src.w <= buf.w) { buf.data.set(src.data.subarray(so, so + src.w * 3), to); continue; }
      for (let x = 0; x < src.w; x++, so += ch) {
        const tx = dx + x;
        if (tx < 0 || tx >= buf.w) continue;
        const o = (ty * buf.w + tx) * 3;
        buf.data[o] = src.data[so]; buf.data[o + 1] = src.data[so + 1]; buf.data[o + 2] = src.data[so + 2];
      }
    }
  }

  // ---------- 文字 ----------
  const scaledCache = new Map();
  function scaledGlyph(atlas, ch, scale) {
    const key = ch + "@" + scale.toFixed(4);
    if (scaledCache.has(key)) return scaledCache.get(key);
    const g = atlas.glyphs[ch];
    if (!g || !g.w) { scaledCache.set(key, null); return null; }
    // 盒式滤波缩小（scale<=1），放大用最近邻（不会用到）
    const w = Math.max(1, Math.round(g.w * scale)), h = Math.max(1, Math.round(g.h * scale));
    const a = new Float32Array(w * h);
    const inv = 1 / scale;
    for (let y = 0; y < h; y++) {
      const sy0 = y * inv, sy1 = Math.min(g.h, (y + 1) * inv);
      for (let x = 0; x < w; x++) {
        const sx0 = x * inv, sx1 = Math.min(g.w, (x + 1) * inv);
        let s = 0, n = 0;
        for (let sy = Math.floor(sy0); sy < Math.ceil(sy1); sy++) {
          const wy = Math.min(sy + 1, sy1) - Math.max(sy, sy0);
          for (let sx = Math.floor(sx0); sx < Math.ceil(sx1); sx++) {
            const wx = Math.min(sx + 1, sx1) - Math.max(sx, sx0);
            s += g.a[sy * g.w + sx] * wx * wy; n += wx * wy;
          }
        }
        a[y * w + x] = n ? s / n / 255 : 0;
      }
    }
    const out = { w, h, a, lsb: g.lsb * scale, top: g.top * scale, adv: g.adv * scale };
    scaledCache.set(key, out);
    return out;
  }

  // size: 字号（px，按 em）；tracking: 额外字距（em 的比例）
  function measureText(atlas, text, size, tracking) {
    const s = size / atlas.em; let x = 0;
    for (const ch of text) {
      const g = atlas.glyphs[ch] || atlas.glyphs["?"];
      x += (g ? g.adv * s : size * 0.5) + size * (tracking || 0);
    }
    return Math.max(0, x - size * (tracking || 0));
  }

  // 文字太长时缩小字号以放进 maxW
  function fitSize(atlas, text, size, maxW, tracking) {
    if (!text || !maxW) return size;
    const w = measureText(atlas, text, size, tracking);
    return w > maxW ? Math.max(6, size * maxW / w) : size;
  }

  // 加粗：同一段文字做几次微小偏移叠画
  function drawTextBold(buf, atlas, text, x, baseline, size, rgb, opt) {
    const d = Math.max(1, size * 0.022);
    let w = 0;
    for (const [ox, oy] of [[0, 0], [d, 0], [0, d * 0.5], [d, d * 0.5]]) w = drawText(buf, atlas, text, x + ox, baseline + oy, size, rgb, opt);
    return w + d;
  }

  // 大写字母的高度（用于对齐）
  function capHeight(atlas, size) {
    const g = atlas.glyphs["H"] || atlas.glyphs["Z"];
    return g ? -g.top * size / atlas.em : size * 0.7;
  }

  function drawText(buf, atlas, text, x, baseline, size, rgb, opt) {
    opt = opt || {};
    const tr = opt.tracking || 0;
    const width = measureText(atlas, text, size, tr);
    if (opt.align === "center") x -= width / 2;
    else if (opt.align === "right") x -= width;
    const s = size / atlas.em;
    let pen = x;
    for (const ch of text) {
      const raw = atlas.glyphs[ch];
      const g = raw ? scaledGlyph(atlas, ch, s) : null;
      if (g) {
        // 亚像素位置取整到像素（小字下足够清晰）
        const gx = Math.round(pen + g.lsb), gy = Math.round(baseline + g.top);
        for (let y = 0; y < g.h; y++) {
          const ty = gy + y; if (ty < 0 || ty >= buf.h) continue;
          for (let xx = 0; xx < g.w; xx++) {
            const tx = gx + xx; if (tx < 0 || tx >= buf.w) continue;
            const a = g.a[y * g.w + xx];
            if (a > 0.004) blend(buf.data, (ty * buf.w + tx) * 3, rgb, a);
          }
        }
        pen += g.adv + size * tr;
      } else {
        pen += size * 0.32 + size * tr;
      }
    }
    return width;
  }

  // ---------- 条码（DX 风格，按胶卷名生成固定图案） ----------
  function hashStr(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function rng(seed) { let t = seed >>> 0; return () => { t += 0x6D2B79F5; let r = Math.imul(t ^ (t >>> 15), 1 | t); r ^= r + Math.imul(r ^ (r >>> 7), 61 | r); return ((r ^ (r >>> 14)) >>> 0) / 4294967296; }; }

  function drawBarcode(buf, x, y, w, h, unit, rgb, seed) {
    const rnd = rng(seed);
    let px = x;
    // 顶部一条细基线 + 下垂的长短齿
    if (w < unit * 4) return;
    fillRect(buf, x, y, x + w, y + Math.max(1, h * 0.16), rgb);
    while (px < x + w - unit) {
      const bw = unit * (rnd() < 0.7 ? 1 : 2);
      const tall = rnd() < 0.45;
      if (rnd() < 0.62) fillRect(buf, px, y, Math.min(x + w, px + bw), y + (tall ? h : h * 0.5), rgb);
      px += bw + unit * (rnd() < 0.5 ? 1 : 2);
    }
  }

  // ---------- 单张画框（比例参照 135 胶片；以照片宽度 W 为基准） ----------
  function frameGeometry(W, H) {
    const side = Math.round(W * 0.036);
    const band = Math.round(W * 0.18);       // 上/下片边带高度
    return {
      side, band,
      cw: W + side * 2, ch: H + band * 2,
      holeW: W * 0.054, holeH: W * 0.08, holeR: W * 0.012,
      holeGap: W * 0.033,                     // 齿孔与画面的距离
      text: W * 0.036,                        // 片边字号
      textBase: W * 0.054,                    // 顶部文字基线（距画布顶）
      barH: W * 0.04, unit: Math.max(2, W * 0.007)
    };
  }

  function drawHoles(buf, x0, x1, yTop, holeW, holeH, r, count, rgb) {
    const pitch = (x1 - x0) / count;
    for (let i = 0; i < count; i++) {
      const cx = x0 + pitch * (i + 0.5);
      fillRoundRect(buf, cx - holeW / 2, yTop, holeW, holeH, r, rgb);
    }
  }

  // 一帧的齿孔（上下各 8 个），返回上/下齿孔的位置
  function drawFrameHoles(buf, g, x0, x1, photoTop, photoBottom, rgb) {
    const holeTopY = photoTop - g.holeGap - g.holeH;
    const holeBotY = photoBottom + g.holeGap;
    drawHoles(buf, x0, x1, holeTopY, g.holeW, g.holeH, g.holeR, 8, rgb);
    drawHoles(buf, x0, x1, holeBotY, g.holeW, g.holeH, g.holeR, 8, rgb);
    return { holeTopY, holeBotEnd: holeBotY + g.holeH };
  }

  // 单张：顶部“序号 + 胶卷名”，底部“序号  序号A →”
  function drawSingleEdge(buf, atlas, g, x0, x1, stripTop, stripBottom, photoTop, photoBottom, frameNo, filmName, style, signature) {
    const W = x1 - x0;
    const h = drawFrameHoles(buf, g, x0, x1, photoTop, photoBottom, style.hole);
    const topBase = stripTop + (h.holeTopY - stripTop) * 0.5 + g.text * 0.36;
    const no = frameNo != null ? String(frameNo) : "";
    if (no) drawText(buf, atlas, no, x0 + W * 0.02, topBase, g.text, style.edge, { tracking: 0.04 });
    if (filmName) {
      const fs = fitSize(atlas, filmName, g.text, W * 0.6, 0.08);
      drawText(buf, atlas, filmName, x0 + W / 2, topBase, fs, style.edge, { align: "center", tracking: 0.08 });
    }
    if (signature) drawText(buf, atlas, signature, x1 - W * 0.02, topBase, g.text, style.edge, { align: "right", tracking: 0.08 });
    if (no) {
      const botBase = h.holeBotEnd + (stripBottom - h.holeBotEnd) * 0.5 + g.text * 0.36;
      drawText(buf, atlas, no, x0 + W * 0.25, botBase, g.text, style.edge, { align: "center", tracking: 0.04 });
      const pA = x0 + W * 0.66;
      const w = drawText(buf, atlas, no + "A", pA, botBase, g.text, style.edge, { tracking: 0.04 });
      fillArrow(buf, pA + w + g.text * 0.25, botBase - g.text * 0.36, g.text * 0.85, Math.max(1, g.text * 0.13), style.edge);
    }
  }

  // photo: {w,h,data,channels}；返回 RGB 缓冲
  function composeFrame(photo, atlas, frameNo, filmName, style, opts) {
    opts = opts || {};
    style = Object.assign({}, STYLE, style || {});
    const g = frameGeometry(photo.w, photo.h);
    const buf = makeBuf(g.cw, g.ch, style.strip);
    const px = g.side, py = g.band;
    blit(buf, photo, px, py);
    drawSingleEdge(buf, atlas, g, px, px + photo.w, 0, g.ch, py, py + photo.h, frameNo, filmName, style, opts.signature);
    return buf;
  }

  // ---------- 预览图底板：径向渐变 + 颗粒 + 纸纹 + 片条投影 ----------
  // style.base: 中心色；style.baseEdge: 边缘色（缺省=纯色）；style.grain: 细颗粒强度；
  // style.mottle: 低频纸纹强度；style.shadow: {a 不透明度, r 柔化半径, dy 下移, rgb}
  function hash2(x, y) {
    let h = (x * 374761393 + y * 668265263) | 0;
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  }
  function valueNoise(x, y, cell) {
    const gx = Math.floor(x / cell), gy = Math.floor(y / cell);
    const fx = x / cell - gx, fy = y / cell - gy;
    const sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy);
    const a = hash2(gx, gy), b = hash2(gx + 1, gy), c = hash2(gx, gy + 1), d = hash2(gx + 1, gy + 1);
    return (a + (b - a) * sx) + ((c + (d - c) * sx) - (a + (b - a) * sx)) * sy;
  }
  function drawBackdrop(buf, style) {
    const c0 = style.base, c1 = style.baseEdge || style.base;
    const grain = style.grain || 0, mottle = style.mottle || 0;
    const W = buf.w, H = buf.h, d = buf.data;
    const cx = W / 2, cy = H * 0.45, R = Math.sqrt(cx * cx + (H * 0.55) * (H * 0.55));
    const flat = c0 === c1 && !grain && !mottle;
    if (flat) { fillRect(buf, 0, 0, W, H, c0); return; }
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const dx = x - cx, dy = y - cy;
        let t = Math.sqrt(dx * dx + dy * dy) / R; t = t * t * (3 - 2 * Math.min(1, t));
        let n = 0;
        if (grain) n += (hash2(x, y) - 0.5) * 2 * grain;
        if (mottle) n += ((valueNoise(x, y, 90) - 0.5) * 0.65 + (valueNoise(x + 911, y + 377, 23) - 0.5) * 0.35) * 2 * mottle;
        const o = (y * W + x) * 3;
        for (let k = 0; k < 3; k++) {
          const v = c0[k] + (c1[k] - c0[k]) * t + n;
          d[o + k] = v < 0 ? 0 : v > 255 ? 255 : v;
        }
      }
    }
  }
  // 片条下方的柔和投影（只画在矩形外侧）
  function drawShadow(buf, x0, y0, x1, y1, sh) {
    if (!sh || !sh.a) return;
    const r = sh.r || 12, dy = sh.dy || 0, rgb = sh.rgb || [0, 0, 0];
    const ya = Math.max(0, Math.floor(y0 + dy - r)), yb = Math.min(buf.h, Math.ceil(y1 + dy + r));
    const xa = Math.max(0, Math.floor(x0 - r)), xb = Math.min(buf.w, Math.ceil(x1 + r));
    const d = buf.data;
    for (let y = ya; y < yb; y++) {
      const qy = Math.max(y0 + dy - y, 0, y - (y1 + dy));
      for (let x = xa; x < xb; x++) {
        if (x >= x0 && x < x1 && y >= y0 && y < y1) continue;
        const qx = Math.max(x0 - x, 0, x - x1);
        const dist = Math.sqrt(qx * qx + qy * qy) / r;
        if (dist >= 1) continue;
        const f = 1 - dist; blend(d, (y * buf.w + x) * 3, rgb, sh.a * f * f);
      }
    }
  }

  // ---------- 整卷预览（印样）：尺寸 2061×2576，7 张一条，最多 6 条 ----------
  const SHEET = {
    W: 2061, H: 2576,
    left: 75, top: 47, stripW: 1911, stripH: 282, gap: 4, perStrip: 7, maxStrips: 6,
    cellW: 257, cellH: 171
  };

  // thumbs: [{w,h,data,channels}]（已按 SHEET.cellW×cellH 裁好）
  function composeSheet(thumbs, atlas, filmName, line1, line2, style, opts) {
    opts = opts || {};
    style = Object.assign({}, STYLE, style || {});
    const S = SHEET;
    const n = Math.min(thumbs.length, S.perStrip * S.maxStrips);
    const strips = Math.max(1, Math.ceil(n / S.perStrip));
    const buf = makeBuf(S.W, S.H);
    drawBackdrop(buf, style);
    const pitch = S.stripW / S.perStrip;
    // 片边几何：以帧宽 cellW 为基准，取与单张画框相同的比例，但齿孔略放大以便在小图中可见
    const g = frameGeometry(S.cellW, S.cellH);
    g.holeW = S.cellW * 0.068; g.holeH = S.cellW * 0.092; g.holeR = S.cellW * 0.018;
    g.text = 13; g.barH = 11; g.unit = 2.2;
    const photoTopOff = Math.round((S.stripH - S.cellH) / 2);
    g.holeGap = Math.max(4, (photoTopOff - g.holeH) * 0.5);
    for (let s = 0; s < strips; s++) {
      const sy = S.top + s * (S.stripH + S.gap), sb = sy + S.stripH;
      drawShadow(buf, S.left, sy, S.left + S.stripW, sb, style.shadow);
      fillRect(buf, S.left, sy, S.left + S.stripW, sb, style.strip);
      let holeTopY = sy, holeBotEnd = sb;
      for (let i = 0; i < S.perStrip; i++) {
        const idx = s * S.perStrip + i;
        const fx0 = S.left + pitch * i, fx1 = fx0 + pitch;
        const px = Math.round(fx0 + (pitch - S.cellW) / 2), py = sy + photoTopOff;
        if (idx < n && thumbs[idx]) blit(buf, thumbs[idx], px, py);
        else fillRect(buf, px, py, px + S.cellW, py + S.cellH, style.empty);
        const h = drawFrameHoles(buf, g, fx0, fx1, py, py + S.cellH, style.sheetHole);
        holeTopY = h.holeTopY; holeBotEnd = h.holeBotEnd;
        // 底部：每帧一个序号，居中
        const botBase = holeBotEnd + (sb - holeBotEnd) * 0.5 + g.text * 0.36;
        drawText(buf, atlas, String(idx + 1), fx0 + pitch * 0.5, botBase, g.text, style.edge, { align: "center", tracking: 0.04 });
      }
      // 顶部：每条三处胶卷名
      if (filmName) {
        const topBase = sy + (holeTopY - sy) * 0.5 + g.text * 0.36;
        const fs = fitSize(atlas, filmName, g.text, S.stripW / 3 - 30, 0.08);
        for (let k = 0; k < 3; k++) drawText(buf, atlas, filmName, S.left + S.stripW * (k / 3) + 12, topBase, fs, style.edge, { tracking: 0.08 });
      }
    }
    // 右下角两行小字
    const rx = S.left + S.stripW, by = S.H - 150;
    const s1 = fitSize(atlas, line1, 34, S.stripW * 0.62, 0.12);
    if (line1) drawText(buf, atlas, line1, rx, by, s1, style.note, { align: "right", tracking: 0.12 });
    if (line2) drawText(buf, atlas, line2, rx, by + 50, 26, style.note, { align: "right", tracking: 0.16 });
    // 签名（个人版）：左下角加粗，顶部不高于右侧第一行文字，底部与第二行基线对齐
    if (opts.signature) {
      const top = by - capHeight(atlas, s1), base = by + 50;
      const size = (base - top) / (capHeight(atlas, 100) / 100);
      drawTextBold(buf, atlas, opts.signature, S.left, base, size, style.note, { tracking: 0.1 });
    }
    return { buf, used: n, strips };
  }

  // 需要预渲染的字符
  const CHARSET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-.·'/+&()";

  const api = { STYLE, SHEET, SHEET_THEMES, sheetStyle, CHARSET, makeBuf, fillRect, fillRoundRect, drawText, measureText, fitSize, composeFrame, composeSheet, frameGeometry };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.FilmFrame = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
