/*
 * film-analyze.js — 135 黑白负片翻拍：调平角度 / 画幅框检测 / 密度统计
 * 纯 JS，无依赖。Photoshop UXP 与 Node 共用（Node 下用于离线测试）。
 *
 * 输入：低分辨率 RGB/RGBA/灰度像素（Uint8Array），一般长边 1000~1400px。
 * 输出（坐标均为分析图坐标，调用方按比例换算到文档）：
 *   angle  : 顺时针旋转角度（度），与 Photoshop 变换的正方向一致
 *   rect   : 旋转后（围绕图像中心）画幅区域 {left, top, right, bottom}
 *   stats  : 画幅内亮度百分位（负片值，0..1）
 *   confidence / warnings
 */
(function (root) {
  "use strict";

  // maxValue：8 位为 255；Photoshop 16 位为 32768；32 位浮点为 1
  function toLuma(data, width, height, channels, maxValue) {
    const n = width * height;
    const L = new Float32Array(n);
    const k = 1 / (maxValue || 255);
    if (channels === 1 || channels === 2) {
      for (let i = 0, j = 0; i < n; i++, j += channels) L[i] = data[j] * k;
    } else {
      for (let i = 0, j = 0; i < n; i++, j += channels) {
        L[i] = (0.2126 * data[j] + 0.7152 * data[j + 1] + 0.0722 * data[j + 2]) * k;
      }
    }
    return L;
  }

  function percentile(arr, p) {
    // 直方图法，arr 为 0..1 浮点
    const bins = 1024;
    const hist = new Uint32Array(bins);
    let count = 0;
    for (let i = 0; i < arr.length; i++) {
      let v = arr[i];
      if (!(v >= 0)) continue;
      if (v > 1) v = 1;
      hist[Math.min(bins - 1, (v * (bins - 1)) | 0)]++;
      count++;
    }
    return histPercentiles(hist, count, [p])[0];
  }

  function histPercentiles(hist, count, ps) {
    const bins = hist.length;
    const out = [];
    for (const p of ps) {
      const target = (p / 100) * count;
      let acc = 0;
      let k = 0;
      for (; k < bins; k++) {
        acc += hist[k];
        if (acc >= target) break;
      }
      out.push(Math.min(1, k / (bins - 1)));
    }
    return out;
  }

  // 3x3 盒式模糊，去掉颗粒和噪点
  function blur3(L, w, h) {
    const tmp = new Float32Array(w * h);
    const out = new Float32Array(w * h);
    for (let y = 0; y < h; y++) {
      const r = y * w;
      for (let x = 0; x < w; x++) {
        const a = L[r + Math.max(0, x - 1)], b = L[r + x], c = L[r + Math.min(w - 1, x + 1)];
        tmp[r + x] = (a + b + c) / 3;
      }
    }
    for (let y = 0; y < h; y++) {
      const ru = Math.max(0, y - 1) * w, r = y * w, rd = Math.min(h - 1, y + 1) * w;
      for (let x = 0; x < w; x++) out[r + x] = (tmp[ru + x] + tmp[r + x] + tmp[rd + x]) / 3;
    }
    return out;
  }

  // 顺时针旋转 deg 度（y 轴向下的屏幕坐标），围绕图像中心，双线性采样，越界填 fill
  function rotateImage(L, w, h, deg, fill) {
    if (Math.abs(deg) < 1e-6) return L;
    const out = new Float32Array(w * h);
    const t = (deg * Math.PI) / 180;
    const c = Math.cos(t), s = Math.sin(t);
    const cx = (w - 1) / 2, cy = (h - 1) / 2;
    for (let y = 0; y < h; y++) {
      const dy = y - cy;
      for (let x = 0; x < w; x++) {
        const dx = x - cx;
        // 逆变换：src = R(-t) * dst
        const sx = cx + dx * c + dy * s;
        const sy = cy - dx * s + dy * c;
        const x0 = Math.floor(sx), y0 = Math.floor(sy);
        if (x0 < 0 || y0 < 0 || x0 >= w - 1 || y0 >= h - 1) { out[y * w + x] = fill; continue; }
        const fx = sx - x0, fy = sy - y0;
        const i = y0 * w + x0;
        out[y * w + x] =
          L[i] * (1 - fx) * (1 - fy) + L[i + 1] * fx * (1 - fy) +
          L[i + w] * (1 - fx) * fy + L[i + w + 1] * fx * fy;
      }
    }
    return out;
  }

  // ---------- 调平：暗区(片夹)边缘点的投影锐度 ----------
  function estimateAngle(dark, w, h, maxDeg) {
    // 收集水平边缘点（上下相邻像素暗/亮不同）和垂直边缘点
    const hx = [], hy = [], vx = [], vy = [];
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const i = y * w + x;
        if (dark[i] !== dark[i + w]) { hx.push(x); hy.push(y + 0.5); }
        if (dark[i] !== dark[i + 1]) { vx.push(x + 0.5); vy.push(y); }
      }
    }
    const cx = (w - 1) / 2, cy = (h - 1) / 2;
    const rowBins = new Float32Array(h + w + 4);
    const colBins = new Float32Array(h + w + 4);
    const off = Math.ceil((w + h) / 2) + 2;

    function score(deg) {
      const t = (deg * Math.PI) / 180, c = Math.cos(t), s = Math.sin(t);
      rowBins.fill(0); colBins.fill(0);
      // 顺时针旋转后的坐标： y' = dx*s + dy*c ; x' = dx*c - dy*s
      for (let k = 0; k < hx.length; k++) {
        const dx = hx[k] - cx, dy = hy[k] - cy;
        const yp = dx * s + dy * c;
        rowBins[(yp + off) | 0] += 1;
      }
      for (let k = 0; k < vx.length; k++) {
        const dx = vx[k] - cx, dy = vy[k] - cy;
        const xp = dx * c - dy * s;
        colBins[(xp + off) | 0] += 1;
      }
      let sc = 0;
      for (let i = 0; i < rowBins.length; i++) sc += rowBins[i] * rowBins[i] + colBins[i] * colBins[i];
      return sc;
    }

    let best = 0, bestScore = -1;
    for (let d = -maxDeg; d <= maxDeg + 1e-9; d += 0.1) {
      const sc = score(d);
      if (sc > bestScore) { bestScore = sc; best = d; }
    }
    const coarse = best;
    for (let d = coarse - 0.12; d <= coarse + 0.12 + 1e-9; d += 0.01) {
      const sc = score(d);
      if (sc > bestScore) { bestScore = sc; best = d; }
    }
    const flat = score(maxDeg); // 参考：用偏离很远的角度作为基线
    return { angle: Math.round(best * 100) / 100, peakRatio: bestScore / Math.max(1, flat), edgePoints: hx.length + vx.length };
  }

  // 在 profile（0..1 的“暗占比”）里找包含/最接近中心的最长非暗区段
  function findOpenRun(profile, lo, hi, thr) {
    const runs = [];
    let start = -1;
    for (let i = lo; i <= hi; i++) {
      const open = i < hi && profile[i] < thr;
      if (open && start < 0) start = i;
      if (!open && start >= 0) { runs.push([start, i - 1]); start = -1; }
    }
    if (!runs.length) return null;
    runs.sort((a, b) => (b[1] - b[0]) - (a[1] - a[0]));
    return runs[0];
  }

  // 在 [a,b] 附近寻找 profile 的最大梯度位置，细化边缘（亚像素不做，1px 精度足够）
  function refineEdge(profile, pos, dir, radius) {
    // dir = +1：外侧在 pos 之前（上/左边缘）；dir = -1：外侧在 pos 之后（下/右边缘）
    let best = pos, bestG = -Infinity;
    for (let p = pos - radius; p <= pos + radius; p++) {
      if (p - 2 < 0 || p + 2 >= profile.length) continue;
      const g = dir > 0 ? profile[p - 2] - profile[p + 1] : profile[p + 2] - profile[p - 1];
      if (g > bestG) { bestG = g; best = p; }
    }
    return best;
  }

  function analyze(input, opts) {
    opts = Object.assign({ maxAngle: 4, darkFrac: 0.06, trimClearMax: 0.07, tightenMax: 0.04, aspect: 1.5 }, opts || {});
    const { width: w, height: h } = input;
    const warnings = [];
    let L = blur3(toLuma(input.data, w, h, input.channels || 4, input.maxValue || 255), w, h);

    // 黑位（片夹）与片基亮度
    const black = percentile(L, 2);
    const white = percentile(L, 99.5);
    if (white - black < 0.15) warnings.push("画面反差过低，可能不是带片夹的翻拍");
    const darkT = black + opts.darkFrac * (white - black);

    const n = w * h;
    let dark = new Uint8Array(n);
    for (let i = 0; i < n; i++) dark[i] = L[i] < darkT ? 1 : 0;

    const darkRatio = dark.reduce((a, b) => a + b, 0) / n;
    // 片夹应当是很黑、并且包围画面四周的区域
    let border = 0, borderDark = 0;
    for (let x = 0; x < w; x += 2) { border += 2; borderDark += dark[x] + dark[(h - 1) * w + x]; }
    for (let y = 0; y < h; y += 2) { border += 2; borderDark += dark[y * w] + dark[y * w + w - 1]; }
    const borderDarkRatio = borderDark / Math.max(1, border);
    const hasHolder = !opts.statsOnly && darkRatio > 0.08 && black < 0.1 && borderDarkRatio > 0.45;
    if (!hasHolder && !opts.statsOnly) warnings.push("未发现黑色片夹区域，跳过自动裁切");

    // 1) 调平
    let angle = 0, peakRatio = 1;
    if (hasHolder) {
      const est = estimateAngle(dark, w, h, opts.maxAngle);
      angle = est.angle; peakRatio = est.peakRatio;
      if (Math.abs(angle) >= opts.maxAngle - 0.05) {
        warnings.push("倾斜角达到搜索上限，已放弃自动调平");
        angle = 0;
      }
    }

    // 2) 旋转后找画幅窗口
    const R = rotateImage(L, w, h, angle, black);
    for (let i = 0; i < n; i++) dark[i] = R[i] < darkT ? 1 : 0;

    let rect = { left: 0, top: 0, right: w, bottom: h };
    let frameFound = false;
    if (hasHolder) {
      const rowDark = new Float32Array(h);
      const x0 = Math.round(w * 0.35), x1 = Math.round(w * 0.65);
      for (let y = 0; y < h; y++) {
        let s = 0;
        for (let x = x0; x < x1; x++) s += dark[y * w + x];
        rowDark[y] = s / (x1 - x0);
      }
      const rr = findOpenRun(rowDark, 0, h, 0.5);
      if (rr) {
        const ry0 = rr[0], ry1 = rr[1];
        const yy0 = Math.round(ry0 + (ry1 - ry0) * 0.3), yy1 = Math.round(ry0 + (ry1 - ry0) * 0.7);
        const colDark = new Float32Array(w);
        for (let x = 0; x < w; x++) {
          let s = 0;
          for (let y = yy0; y < yy1; y++) s += dark[y * w + x];
          colDark[x] = s / Math.max(1, yy1 - yy0);
        }
        const cr = findOpenRun(colDark, 0, w, 0.5);
        if (cr) {
          // 用该区域重新计算行暗占比（只看画幅横向范围），并细化四边
          const rowDark2 = new Float32Array(h);
          const xa = Math.round(cr[0] + (cr[1] - cr[0]) * 0.1), xb = Math.round(cr[1] - (cr[1] - cr[0]) * 0.1);
          for (let y = 0; y < h; y++) {
            let s = 0;
            for (let x = xa; x < xb; x++) s += dark[y * w + x];
            rowDark2[y] = s / Math.max(1, xb - xa);
          }
          const rr2 = findOpenRun(rowDark2, 0, h, 0.5) || rr;
          const rad = Math.max(3, Math.round(Math.min(w, h) * 0.006));
          rect = {
            left: refineEdge(colDark, cr[0], +1, rad),
            right: refineEdge(colDark, cr[1], -1, rad) + 1,
            top: refineEdge(rowDark2, rr2[0], +1, rad),
            bottom: refineEdge(rowDark2, rr2[1], -1, rad) + 1
          };
          frameFound = true;
        }
      }
      if (!frameFound) warnings.push("未能识别画幅窗口");
    }

    // 3) 去掉窗口内侧的片基透明条（相邻帧间隔 / 片门外未曝光区）。
    //    特征：紧贴边缘、沿边方向非常均匀、接近片基亮度，然后向内出现明显的亮度台阶。
    const trims = { left: 0, right: 0, top: 0, bottom: 0 };
    if (frameFound) {
      const fw0 = rect.right - rect.left, fh0 = rect.bottom - rect.top;
      const baseT = white - 0.15 * (white - black);
      const lineStats = (vertical, pos) => {
        // vertical=true：统计第 pos 列；否则第 pos 行。只取中间 90%
        let s = 0, s2 = 0, t = 0;
        if (vertical) {
          for (let y = rect.top + Math.round(fh0 * 0.05); y < rect.bottom - Math.round(fh0 * 0.05); y++) { const v = R[y * w + pos]; s += v; s2 += v * v; t++; }
        } else {
          for (let x = rect.left + Math.round(fw0 * 0.05); x < rect.right - Math.round(fw0 * 0.05); x++) { const v = R[pos * w + x]; s += v; s2 += v * v; t++; }
        }
        const m = s / Math.max(1, t);
        return [m, Math.sqrt(Math.max(0, s2 / Math.max(1, t) - m * m))];
      };
      const stripWidth = (vertical, from, dir, maxK) => {
        const m = [], sd = [];
        for (let k = 0; k < maxK + 12; k++) { const r = lineStats(vertical, from + dir * k); m.push(r[0]); sd.push(r[1]); }
        let k0 = 0;
        while (k0 < maxK - 1 && m[k0 + 1] > m[k0] + 0.01) k0++;
        let best = -1, bestD = 0.04;
        for (let k = k0; k <= maxK; k++) { const D = m[k] - m[k + 3]; if (D > bestD) { bestD = D; best = k; } }
        if (best < 0) return 0;
        let sm = 0, smax = 0;
        for (let k = k0; k <= best; k++) { sm += m[k]; smax = Math.max(smax, sd[k]); }
        sm /= best - k0 + 1;
        let inner = 0;
        for (let k = best + 4; k < best + 10; k++) inner += m[k];
        inner /= 6;
        if (smax > 0.045 || sm - inner < 0.04 || sm < baseT) return 0;
        return best + 3;
      };
      const maxX = Math.round(fw0 * opts.trimClearMax), maxY = Math.round(fh0 * opts.trimClearMax);
      trims.left = stripWidth(true, rect.left, +1, maxX);
      trims.right = stripWidth(true, rect.right - 1, -1, maxX);
      trims.top = stripWidth(false, rect.top, +1, maxY);
      trims.bottom = stripWidth(false, rect.bottom - 1, -1, maxY);
      rect.left += trims.left; rect.right -= trims.right;
      rect.top += trims.top; rect.bottom -= trims.bottom;
    }

    // 3b) 收紧四边：片夹边缘是虚的（反色后成白边），并且画幅四角略圆。
    //     沿每条边向内走，直到该行/列（去掉两端 4%）中最暗的 3% 像素也明显亮于片夹黑，
    //     并且亮度不再上升为止，再多收 1 像素。
    const tight = { left: 0, right: 0, top: 0, bottom: 0 };
    if (frameFound) {
      const fw1 = rect.right - rect.left, fh1 = rect.bottom - rect.top;
      const lineInfo = (vertical, pos) => {
        const vals = [];
        if (vertical) {
          const a = rect.top + Math.round(fh1 * 0.04), b = rect.bottom - Math.round(fh1 * 0.04);
          for (let y = a; y < b; y++) vals.push(R[y * w + pos]);
        } else {
          const a = rect.left + Math.round(fw1 * 0.04), b = rect.right - Math.round(fw1 * 0.04);
          for (let x = a; x < b; x++) vals.push(R[pos * w + x]);
        }
        let s = 0; for (const v of vals) s += v;
        vals.sort((p, q) => p - q);
        return { m: s / Math.max(1, vals.length), lo: vals[Math.floor(vals.length * 0.03)] || 0 };
      };
      const loT = darkT + 0.5 * (darkT - black);
      const tighten = (vertical, from, dir, maxK) => {
        const info = [];
        for (let k = 0; k <= maxK + 4; k++) info.push(lineInfo(vertical, from + dir * k));
        for (let k = 0; k <= maxK; k++) {
          const rising = info[k + 3].m - info[k].m > 0.015 || info[k + 1].m - info[k].m > 0.008;
          if (info[k].lo > loT && !rising) return Math.min(maxK, k + 1);
        }
        return maxK;
      };
      const mx = Math.round(fw1 * opts.tightenMax), my = Math.round(fh1 * opts.tightenMax);
      tight.left = tighten(true, rect.left, +1, mx);
      tight.right = tighten(true, rect.right - 1, -1, mx);
      tight.top = tighten(false, rect.top, +1, my);
      tight.bottom = tighten(false, rect.bottom - 1, -1, my);
      // 某边一直“没走出”暗区（画面本身在这一侧就很暗/很密），说明判断失效：
      // 用其它边的收紧量中位数代替（同一片夹四边的虚化宽度基本一致）
      const capped = { left: tight.left >= mx, right: tight.right >= mx, top: tight.top >= my, bottom: tight.bottom >= my };
      const okVals = ["left", "right", "top", "bottom"].filter((k) => !capped[k]).map((k) => tight[k]).sort((a, b) => a - b);
      const fallback = okVals.length ? okVals[Math.floor(okVals.length / 2)] : Math.round(Math.min(fw1, fh1) * 0.015);
      for (const k of ["left", "right", "top", "bottom"]) if (capped[k]) tight[k] = fallback;
      rect.left += tight.left; rect.right -= tight.right;
      rect.top += tight.top; rect.bottom -= tight.bottom;
    }

    // 4) 置信度检查
    let confidence = frameFound ? 1 : 0;
    const fw = rect.right - rect.left, fh = rect.bottom - rect.top;
    const ratio = Math.max(fw, fh) / Math.max(1, Math.min(fw, fh));
    if (frameFound) {
      const ratioErr = Math.abs(ratio - opts.aspect) / opts.aspect;
      if (ratioErr > 0.08) { confidence -= 0.5; warnings.push("画幅比例 " + ratio.toFixed(2) + " 偏离 3:2，裁切可能不准"); }
      const area = (fw * fh) / (w * h);
      if (area < 0.15) { confidence -= 0.4; warnings.push("识别到的画幅过小"); }
      if (area > 0.95) { confidence -= 0.4; warnings.push("识别到的画幅接近整张，可能没有找到片夹边缘"); }
      if (peakRatio < 1.3) { confidence -= 0.2; warnings.push("调平信号较弱"); }
    }

    // 5) 统计画幅内（再内缩 3%）的负片亮度分布
    const statRect = inset(rect, 0.03);
    const hist = new Uint32Array(1024);
    let cnt = 0;
    for (let y = statRect.top; y < statRect.bottom; y++) {
      for (let x = statRect.left; x < statRect.right; x++) {
        const v = R[y * w + x];
        hist[Math.min(1023, (Math.max(0, Math.min(1, v)) * 1023) | 0)]++;
        cnt++;
      }
    }
    const pr = histPercentiles(hist, cnt, [0.1, 0.5, 1, 50, 99, 99.5, 99.9]);
    // 片基（透明片边/齿孔槽）亮度：画幅外、非片夹区域的高百分位
    let filmBase = null;
    if (frameFound) {
      const hb = new Uint32Array(1024); let cb = 0;
      for (let y = 0; y < h; y += 2) for (let x = 0; x < w; x += 2) {
        if (x >= rect.left - 4 && x < rect.right + 4 && y >= rect.top - 4 && y < rect.bottom + 4) continue;
        const v = R[y * w + x];
        if (v < darkT * 3) continue;
        hb[Math.min(1023, (Math.max(0, Math.min(1, v)) * 1023) | 0)]++; cb++;
      }
      if (cb > 200) filmBase = histPercentiles(hb, cb, [90])[0];
    }
    const stats = { filmBase, p0_1: pr[0], p0_5: pr[1], p1: pr[2], median: pr[3], p99: pr[4], p99_5: pr[5], p99_9: pr[6], holderBlack: black, brightest: white };

    return {
      width: w, height: h, angle, rect, trims, tight, ratio: Math.round(ratio * 1000) / 1000,
      confidence: Math.max(0, Math.round(confidence * 100) / 100), frameFound, warnings, stats, peakRatio: Math.round(peakRatio * 100) / 100
    };
  }

  function inset(rect, frac) {
    const dx = Math.round((rect.right - rect.left) * frac), dy = Math.round((rect.bottom - rect.top) * frac);
    return { left: rect.left + dx, top: rect.top + dy, right: rect.right - dx, bottom: rect.bottom - dy };
  }

  // ---------- 由统计值计算反色定标（Levels，作用在反色之后） ----------
  // clipShadow/clipHighlight 为百分比；返回 0..255 的输入黑/白场与 gamma
  function computeLevels(stats, opt) {
    opt = Object.assign({ clip: 0.5, autoGamma: true, targetMid: 0.46, gammaMin: 0.75, gammaMax: 1.35 }, opt || {});
    const pick = (c) => (c <= 0.1 ? [stats.p0_1, stats.p99_9] : c <= 0.5 ? [stats.p0_5, stats.p99_5] : [stats.p1, stats.p99]);
    const [dense, thin] = pick(opt.clip);
    // 反色后：v' = 1 - v。最薄（片基附近）-> 黑，最密 -> 白
    let inBlack = Math.round((1 - thin) * 255);
    let inWhite = Math.round((1 - dense) * 255);
    // 限制最大拉伸（极平的画面不要把颗粒/噪点放大太多）
    const minRange = opt.minRange || 90;
    if (inWhite - inBlack < minRange) {
      const c = (inWhite + inBlack) / 2;
      inBlack = Math.round(c - minRange / 2); inWhite = Math.round(c + minRange / 2);
      if (inBlack < 0) { inWhite -= inBlack; inBlack = 0; }
      if (inWhite > 255) { inBlack -= inWhite - 255; inWhite = 255; }
    }
    let gamma = 1;
    if (opt.autoGamma) {
      const mid = 1 - stats.median;
      const m = Math.min(0.98, Math.max(0.02, (mid * 255 - inBlack) / (inWhite - inBlack)));
      gamma = Math.log(m) / Math.log(opt.targetMid);
      gamma = Math.min(opt.gammaMax, Math.max(opt.gammaMin, gamma));
      gamma = Math.round(gamma * 100) / 100;
    }
    return { inBlack: Math.max(0, inBlack), inWhite: Math.min(255, inWhite), gamma };
  }

  // ---------- 影调参数 -> 曲线点 ----------
  // p: {exposure(-100..100), contrast(-100..100), highlights(-100..100), shadows(-100..100), blacks(0..60), whites(0..60)}
  function toneCurve(p) {
    p = Object.assign({ exposure: 0, contrast: 0, highlights: 0, shadows: 0, blacks: 0, whites: 0 }, p || {});
    const g = Math.pow(2, p.exposure / 100); // 曝光：中间调幂函数
    const base = (x) => Math.pow(x, 1 / g);
    const k = p.contrast / 100;
    const xs = [0.125, 0.25, 0.5, 0.75, 0.875];
    const pts = [[0, 0]];
    for (const x of xs) {
      let y = base(x);
      // 对比：围绕 0.5 的 S 曲线
      y = y + k * 0.5 * Math.sin(2 * Math.PI * (y - 0.5)) / Math.PI * 1.2;
      // 高光 / 阴影：分别作用在 0.75 / 0.25 附近
      const hw = Math.exp(-Math.pow((x - 0.8) / 0.15, 2));
      const sw = Math.exp(-Math.pow((x - 0.2) / 0.15, 2));
      y += (p.highlights / 100) * 0.12 * hw + (p.shadows / 100) * 0.12 * sw;
      pts.push([x, y]);
    }
    pts.push([1, 1]);
    // 黑位/白位：输入端压缩（加深黑、提亮白）
    const b = p.blacks / 255, wv = p.whites / 255;
    const out = pts.map(([x, y]) => [x, y]);
    out[0] = [Math.min(0.4, b), 0];
    out[out.length - 1] = [Math.max(0.6, 1 - wv), 1];
    // 保证单调并转为 0..255 整数，横坐标严格递增
    let prevX = -1, prevY = -1;
    const res = [];
    for (const [x, y] of out) {
      let X = Math.round(Math.max(0, Math.min(1, x)) * 255);
      let Y = Math.round(Math.max(0, Math.min(1, y)) * 255);
      if (X <= prevX) continue;
      if (X < out[0][0] * 255 + 1 && res.length) continue;
      if (Y < prevY) Y = prevY;
      res.push([X, Y]);
      prevX = X; prevY = Y;
    }
    // 去掉落在黑白位之外的中间点
    const xb = res[0][0], xw = Math.round(out[out.length - 1][0] * 255);
    const filtered = res.filter((pt, i) => i === 0 || (pt[0] > xb && pt[0] < xw));
    filtered.push([xw, 255]);
    return filtered;
  }

  const api = { analyze, computeLevels, toneCurve, rotateImage, toLuma, inset };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.FilmAnalyze = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
