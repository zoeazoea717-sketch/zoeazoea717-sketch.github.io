/* 版本配置：personal = 个人版（带 ZOEA 签名）；public = 公开发布版 */
module.exports = { edition: "public", signature: null };
