/*
 * 胶片翻拍助手 — Photoshop UXP 面板（135 黑白负片整卷翻拍）
 * 流程：整卷批量（JPEG / RAW）→ 自动调平 → 自动裁切 → 黑白 + 反色 + 定标 + 影调（全部为可再编辑的图层）
 *       → 保存 PSD（可再编辑）+ 导出 JPEG
 */
"use strict";

const { app, core, action } = require("photoshop");
const uxp = require("uxp");
const fs = uxp.storage.localFileSystem;
const FA = require("./film-analyze.js");
const ps = require("./ps-ops.js");
const FF = require("./film-frame.js");
const { FILM_STOCKS } = require("./film-stocks.js");
let EDITION = { edition: "public", signature: null };
try { EDITION = require("./edition.js"); } catch (e) { /* 没有 edition.js 时按公开版处理 */ }
const { LAYER } = ps;

const IMAGE_EXT = ["jpg", "jpeg", "tif", "tiff", "png", "psd"];
const RAW_EXT = ["raf", "nef", "nrw", "cr2", "cr3", "crw", "arw", "srf", "sr2", "dng", "orf", "rw2", "pef", "srw", "x3f", "3fr", "fff", "iiq", "rwl", "erf", "mef", "mos", "kdc"];
const OUT_DIR = "_film135";
const JPG_DIR = "JPEG";
const ANALYSIS_SIZE = 1200;
const FRAME_DIR = "JPEG_画框";
const FRAME_FONT = { ps: "Jura-Bold", family: "Jura", style: "Bold" };
const ATLAS_EM = 160;
// Jura 不含的字符（中文等）改用系统黑体
const FALLBACK_FONTS = ["SimHei", "MicrosoftYaHei", "MicrosoftYaHeiUI", "DengXian-Regular", "PingFangSC-Regular", "STHeitiSC-Medium",
  "HiraginoSansGB-W3", "SourceHanSansSC-Regular", "NotoSansCJKsc-Regular", "AdobeHeitiStd-Regular", "ArialMT"];
const SHEET_MAX = FF.SHEET.perStrip * FF.SHEET.maxStrips; // 42

const $ = (id) => document.getElementById(id);
const state = {
  rollFolder: null,
  running: false,
  stop: false
};

// ======================== 设置 ========================
const DEFAULTS = {
  subRolls: false, mode: "frame", clip: 0.5, autoGamma: true, inset: 0.5,
  psd: true, jpegQ: 11, rename: false, filmMaker: "", filmModel: "", frame: false, psdCompress: false,
  sheetBg: "dark", sheetText: "orange"
};

function loadSettings() {
  try {
    const s = JSON.parse(localStorage.getItem("film135roll.settings") || "{}");
    if (s.filmStock && !s.filmModel) s.filmModel = s.filmStock; // 旧版设置迁移
    return Object.assign({}, DEFAULTS, s);
  } catch (e) { return JSON.parse(JSON.stringify(DEFAULTS)); }
}
function saveSettings() {
  try { localStorage.setItem("film135roll.settings", JSON.stringify(readSettings())); } catch (e) { /* ignore */ }
}
// 勾选“按卷名命名”才显示胶卷菜单和胶片画框；勾选“导出 PSD”才显示 PSD 压缩
function updateDependentUI() {
  const showFilm = $("optRename").checked;
  $("rowFilm").style.display = showFilm ? "block" : "none";
  if (!showFilm) hideFilmList();
  $("rowPsdCompress").style.display = $("optPsd").checked ? "flex" : "none";
  // 勾选“胶片画框”才显示整卷预览图的底色 / 文字颜色
  const showSheet = $("optFrame").checked && showFilm;
  $("rowSheetStyle").style.display = showSheet ? "block" : "none";
  if (!showSheet) hideSheetList();
  updateSheetPickers();
}
function readSettings() {
  return {
    subRolls: $("optSubRolls").checked,
    mode: $("optMode").value,
    clip: parseFloat($("optClip").value),
    autoGamma: $("optAutoGamma").checked,
    inset: Math.max(0, Math.min(5, parseFloat($("optInset").value) || 0)),
    psd: $("optPsd").checked,
    jpegQ: 12,
    rename: $("optRename").checked,
    filmMaker: ($("optFilmMaker").value || "").trim(),
    filmModel: ($("optFilmModel").value || "").trim(),
    frame: $("optRename").checked && $("optFrame").checked, // 画框只在“按卷名命名”打开时生效
    frameChecked: $("optFrame").checked,
    psdCompress: $("optPsdCompress").checked,
    sheetBg: sheetPick.bg,
    sheetText: sheetPick.text
  };
}
function filmStockOf(s) { return [s.filmMaker, s.filmModel].filter(Boolean).join(" ").trim(); }
function filmEdgeName(s) { return filmStockOf(s).toUpperCase(); }
function applySettingsToUI(s) {
  $("optSubRolls").checked = s.subRolls;
  $("optMode").value = s.mode;
  $("optClip").value = String(s.clip);
  $("optAutoGamma").checked = s.autoGamma;
  $("optInset").value = String(s.inset);
  $("optPsd").checked = s.psd !== false;
  $("optRename").checked = s.rename;
  $("optFilmMaker").value = s.filmMaker || "";
  $("optFilmModel").value = s.filmModel || "";
  $("optFrame").checked = !!(s.frameChecked != null ? s.frameChecked : s.frame);
  $("optPsdCompress").checked = !!s.psdCompress;
  sheetPick.bg = SHEET_BG_LABEL[s.sheetBg] ? s.sheetBg : "dark";
  sheetPick.text = SHEET_TEXT_LABEL[s.sheetText] ? s.sheetText : "orange";
  updateDependentUI();
}

const levelsName = (lv) => `${LAYER.levels} 黑${lv.inBlack} 白${lv.inWhite} γ${lv.gamma.toFixed(2)}`;

// ======================== 日志 ========================
function log(msg, kind) {
  const el = document.createElement("div");
  el.className = "log-line" + (kind ? " " + kind : "");
  el.textContent = msg;
  const box = $("log");
  box.appendChild(el);
  while (box.childNodes.length > 300) box.removeChild(box.firstChild);
  box.scrollTop = box.scrollHeight;
}
function setStatus(msg, isError) {
  $("status").textContent = msg;
  $("status").className = isError ? "status error" : "status";
}
function setProgress(done, total) {
  const pct = total ? Math.round((done / total) * 100) : 0;
  $("progressBar").style.width = pct + "%";
}

// ======================== 文件工具 ========================
const extOf = (name) => (name.lastIndexOf(".") > 0 ? name.slice(name.lastIndexOf(".") + 1).toLowerCase() : "");
const stemOf = (name) => (name.lastIndexOf(".") > 0 ? name.slice(0, name.lastIndexOf(".")) : name);
const isImage = (e) => e.isFile && (IMAGE_EXT.includes(extOf(e.name)) || RAW_EXT.includes(extOf(e.name)));

async function listImages(folder) {
  const entries = await folder.getEntries();
  const files = entries.filter(isImage).filter((e) => !/^\./.test(e.name));
  // 同名 RAW + JPEG（RAW+JPG 拍摄）时只用 RAW
  const rawStems = new Set(files.filter((e) => RAW_EXT.includes(extOf(e.name))).map((e) => stemOf(e.name).toLowerCase()));
  const picked = files.filter((e) => RAW_EXT.includes(extOf(e.name)) || !rawStems.has(stemOf(e.name).toLowerCase()));
  picked.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));
  return picked;
}

async function getOrCreateFolder(parent, name) {
  try {
    const e = await parent.getEntry(name);
    if (e && e.isFolder) return e;
  } catch (e) { /* 不存在 */ }
  return parent.createFolder(name);
}

async function rollsFromFolder(folder, subRolls) {
  if (!subRolls) return [folder];
  const entries = await folder.getEntries();
  const rolls = [];
  for (const e of entries) {
    if (!e.isFolder || e.name.startsWith("_") || e.name.startsWith(".")) continue;
    const imgs = await listImages(e);
    if (imgs.length) rolls.push(e);
  }
  rolls.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));
  return rolls;
}

function dirOfPath(p) { return p.replace(/[\\/][^\\/]*$/, ""); }

async function folderForNativePath(dir) {
  const fwd = dir.replace(/\\/g, "/");
  const candidates = ["file:" + dir, "file:/" + fwd, "file:///" + fwd.replace(/^\/+/, "")];
  for (const url of candidates) {
    try {
      const e = await fs.getEntryWithUrl(url);
      if (e && e.isFolder) return e;
    } catch (e) { /* 下一个 */ }
  }
  // 退路：之前保存过的授权
  try {
    const map = JSON.parse(localStorage.getItem("film135roll.tokens") || "{}");
    if (map[dir]) return await fs.getEntryForPersistentToken(map[dir]);
  } catch (e) { /* ignore */ }
  setStatus("请选择文件夹：" + dir);
  const picked = await fs.getFolder();
  if (picked) await rememberFolder(dir, picked);
  return picked;
}

async function rememberFolder(nativeDir, folderEntry) {
  try {
    const map = JSON.parse(localStorage.getItem("film135roll.tokens") || "{}");
    map[nativeDir] = await fs.createPersistentToken(folderEntry);
    localStorage.setItem("film135roll.tokens", JSON.stringify(map));
  } catch (e) { /* ignore */ }
}

async function writeJson(folder, name, obj) {
  const f = await folder.createFile(name, { overwrite: true });
  await f.write(JSON.stringify(obj, null, 2));
}
async function readJson(folder, name) {
  try {
    const f = await folder.getEntry(name);
    return JSON.parse(await f.read());
  } catch (e) { return null; }
}

// ======================== 核心：处理一个已打开的文档 ========================
function hasPluginLayers(doc) {
  return !!ps.findLayer(doc, LAYER.invert);
}

async function ensureBaseLayer(doc) {
  let base = ps.findLayer(doc, LAYER.base);
  if (base) return base;
  if (doc.layers.length !== 1) throw new Error("当前文档有多个图层，请先合并为一个负片图层（或只保留负片）。");
  base = doc.layers[0];
  await ps.selectLayer(base).catch(() => {});
  const kindName = String(base.kind || "").toLowerCase();
  if (kindName.indexOf("smart") < 0) {
    await ps.convertActiveToSmartObject();
    base = doc.activeLayers[0];
  }
  base.name = LAYER.base;
  return base;
}

function docRectFromAnalysis(res, px, settings) {
  const r = res.rect;
  let left = r.left * px.scaleX, right = r.right * px.scaleX;
  let top = r.top * px.scaleY, bottom = r.bottom * px.scaleY;
  const m = (Math.min(right - left, bottom - top) * settings.inset) / 100;
  left += m; right -= m; top += m; bottom -= m;
  return { left: Math.round(left), top: Math.round(top), right: Math.round(right), bottom: Math.round(bottom) };
}

async function processDocument(doc, settings, opt) {
  opt = opt || {};
  if (hasPluginLayers(doc)) throw new Error("该文档已经处理过（存在“反色”图层）。如需重新检测请用“重新检测调平/裁切”。");
  const base = await ensureBaseLayer(doc);
  await ps.convertDepth(settings.psdCompress ? 8 : 16);

  // 1) 分析负片
  const px = await ps.readComposite(doc, ANALYSIS_SIZE);
  const res = FA.analyze(px);
  const info = {
    angle: 0, crop: null, confidence: res.confidence, warnings: res.warnings.slice(),
    ratio: res.ratio, stats: res.stats, trims: res.trims, geometryApplied: false
  };

  // 2) 调平 + 裁切（置信度不足时只做反色，保留整张供手动处理）
  if (res.frameFound && res.confidence >= 0.5) {
    await ps.selectLayer(base);
    await ps.rotateActiveLayer(res.angle);
    const rect = docRectFromAnalysis(res, px, settings);
    await ps.cropDoc(doc, rect);
    info.angle = res.angle;
    info.crop = rect;
    info.geometryApplied = true;
  } else {
    info.warnings.push("未自动调平/裁切，请手动处理");
  }

  // 3) 反色定标（裁切后的画幅统计更准确：重新取一次像素）
  let stats = res.stats;
  if (info.geometryApplied) {
    try {
      const px2 = await ps.readComposite(doc, ANALYSIS_SIZE);
      const r2 = FA.analyze(px2, { statsOnly: true });
      stats = Object.assign({}, r2.stats, { filmBase: res.stats.filmBase });
    } catch (e) { /* 用第一次统计 */ }
  }
  const lv = opt.levels || FA.computeLevels(stats, { clip: settings.clip, autoGamma: settings.autoGamma });
  info.stats = stats;
  info.levels = lv;
  if (opt.analyzeOnly) return info;

  // 4) 图层栈：负片 → 黑白 → 反色 → 反色定标（均可双击再编辑）
  await ps.selectLayer(base);
  await ps.makeAdjustment(doc, ps.bwDesc(), LAYER.bw);
  await ps.makeAdjustment(doc, { _obj: "invert" }, LAYER.invert);
  await ps.makeAdjustment(doc, ps.levelsDesc(lv), levelsName(lv));
  return info;
}

// ======================== 整卷批量 ========================
const safeName = (s) => String(s || "").trim().replace(/[\\/:*?"<>|]+/g, "-").replace(/\s+/g, " ");
function outputStem(rollName, entry, index, settings) {
  if (!settings.rename) return stemOf(entry.name);
  const parts = [safeName(rollName)];
  if (safeName(filmStockOf(settings))) parts.push(safeName(filmStockOf(settings)));
  parts.push(String(index + 1).padStart(2, "0"));
  return parts.join("_");
}

// 打开一张、处理、按设置保存/导出、关闭。opt.analyzeOnly 时只分析不出图
async function processFile(entry, settings, outFolder, jpgFolder, stem, opt) {
  let info = null;
  await core.executeAsModal(async () => {
    const token = fs.createSessionToken(entry);
    let doc;
    try { doc = await ps.openAsSmartObject(token); }
    catch (e) { doc = await ps.openPlain(token); }
    try {
      info = await processDocument(doc, settings, opt);
      if (opt && opt.analyzeOnly) return;
      if (settings.psd) {
        const psdEntry = await outFolder.createFile(stem + ".psd", { overwrite: true });
        await ps.savePsd(doc, psdEntry, !settings.psdCompress);
      }
      const jpgEntry = await jpgFolder.createFile(stem + ".jpg", { overwrite: true });
      const fr = opt && opt.frame;
      let full = null;
      await ps.exportJpeg(doc, jpgEntry, settings.jpegQ, fr ? async (dup) => {
        full = await ps.readFullRGB(dup);
        if (fr.wantThumb) info.thumb = await ps.readThumb(dup, FF.SHEET.cellW, FF.SHEET.cellH);
      } : null);
      if (fr && full) {
        const buf = FF.composeFrame(full, state.atlas, fr.no, filmEdgeName(settings), null, { signature: EDITION.signature });
        full = null;
        const fEntry = await fr.folder.createFile(stem + ".jpg", { overwrite: true });
        await ps.saveRgbAsJpeg(buf, fEntry, settings.jpegQ, stem + "_画框");
      }
    } finally {
      await doc.closeWithoutSaving();
    }
  }, { commandName: "胶片翻拍助手：" + entry.name });
  return info;
}

// ---------- 胶片画框：字形图集（Jura Bold） ----------
function b64encode(u8) {
  const T = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  let s = "", i = 0;
  for (; i + 2 < u8.length; i += 3) { const n = (u8[i] << 16) | (u8[i + 1] << 8) | u8[i + 2]; s += T[n >> 18] + T[(n >> 12) & 63] + T[(n >> 6) & 63] + T[n & 63]; }
  if (i < u8.length) { const n = (u8[i] << 16) | ((u8[i + 1] || 0) << 8); s += T[n >> 18] + T[(n >> 12) & 63] + (i + 1 < u8.length ? T[(n >> 6) & 63] : "=") + "="; }
  return s;
}
function b64decode(s) {
  const T = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  const L = new Uint8Array(128); for (let i = 0; i < 64; i++) L[T.charCodeAt(i)] = i;
  const clean = s.replace(/=+$/, ""); const out = new Uint8Array(Math.floor(clean.length * 3 / 4));
  let o = 0;
  for (let i = 0; i < clean.length; i += 4) {
    const n = (L[clean.charCodeAt(i)] << 18) | (L[clean.charCodeAt(i + 1)] << 12) | ((L[clean.charCodeAt(i + 2)] || 0) << 6) | (L[clean.charCodeAt(i + 3)] || 0);
    if (o < out.length) out[o++] = (n >> 16) & 255; if (o < out.length) out[o++] = (n >> 8) & 255; if (o < out.length) out[o++] = n & 255;
  }
  return out;
}
const ATLAS_FILE = () => `atlas-${FRAME_FONT.ps}-${ATLAS_EM}-v1.json`;

async function loadAtlasCache(fontName) {
  try {
    const dir = await fs.getDataFolder();
    const f = await dir.getEntry(ATLAS_FILE());
    const j = JSON.parse(await f.read());
    if (j.font !== fontName || j.em !== ATLAS_EM) return null;
    for (const k in j.glyphs) j.glyphs[k].a = b64decode(j.glyphs[k].a || "");
    return j;
  } catch (e) { return null; }
}
async function saveAtlasCache(atlas) {
  try {
    const dir = await fs.getDataFolder();
    const out = { em: atlas.em, font: atlas.font, glyphs: {} };
    for (const k in atlas.glyphs) { const g = atlas.glyphs[k]; out.glyphs[k] = Object.assign({}, g, { a: b64encode(g.a) }); }
    const f = await dir.createFile(ATLAS_FILE(), { overwrite: true });
    await f.write(JSON.stringify(out));
  } catch (e) { /* 缓存失败不影响使用 */ }
}

// 插件自带的 Jura Bold 字形（由 Jura-Bold.ttf 预先渲染），不依赖电脑上是否装了 Jura、Photoshop 能否识别
async function loadBundledAtlas() {
  try {
    const dir = await fs.getPluginFolder();
    const f = await dir.getEntry("jura-atlas.json");
    const j = JSON.parse(await f.read());
    if (j.em !== ATLAS_EM || !j.glyphs) return null;
    for (const k in j.glyphs) j.glyphs[k].a = b64decode(j.glyphs[k].a || "");
    return j;
  } catch (e) { return null; }
}

// 确保字形图集可用：优先用插件自带的 Jura Bold；万一缺失，才在 Photoshop 里现场渲染
async function ensureAtlas() {
  if (state.atlas) return state.atlas;
  const bundled = await loadBundledAtlas();
  if (bundled) { state.atlas = bundled; return bundled; }
  log("插件自带的 Jura 字形文件缺失，改为在 Photoshop 里生成", "warn");
  let fontName = null;
  await core.executeAsModal(async () => { fontName = ps.findFont(FRAME_FONT.ps, FRAME_FONT.family, FRAME_FONT.style); }, { commandName: "胶片翻拍助手：查找字体" });
  if (!fontName) {
    log("未找到 Jura Bold 字体，画框文字改用 Arial", "warn");
    fontName = "ArialMT";
  }
  let atlas = await loadAtlasCache(fontName);
  if (!atlas) {
    setStatus("首次使用画框：正在用 " + fontName + " 生成字形（约半分钟）…");
    await core.executeAsModal(async () => { atlas = await ps.buildAtlas(FF.CHARSET, fontName, ATLAS_EM); }, { commandName: "胶片翻拍助手：准备画框字体" });
    await saveAtlasCache(atlas);
  }
  state.atlas = atlas;
  return atlas;
}

// 文字里有 Jura 没有的字符（中文、特殊符号）时，用系统黑体补齐这些字形
const fallbackFile = (font) => `atlas-fallback-${font}-${ATLAS_EM}-v1.json`;
async function ensureGlyphs(texts) {
  const atlas = await ensureAtlas();
  const missing = [];
  for (const t of texts) for (const ch of String(t || "")) {
    if (/\s/.test(ch) || atlas.glyphs[ch] || missing.includes(ch)) continue;
    missing.push(ch);
  }
  if (!missing.length) return;
  let font = null;
  await core.executeAsModal(async () => { font = ps.findFirstFont(FALLBACK_FONTS); }, { commandName: "胶片翻拍助手：查找黑体" });
  if (!font) { log("未找到可用的中文字体，部分文字可能无法显示", "warn"); return; }
  // 读缓存
  let cache = { em: ATLAS_EM, font, glyphs: {} };
  try {
    const dir = await fs.getDataFolder();
    const f = await dir.getEntry(fallbackFile(font));
    const j = JSON.parse(await f.read());
    if (j.em === ATLAS_EM) { cache = j; for (const k in cache.glyphs) cache.glyphs[k].a = b64decode(cache.glyphs[k].a || ""); }
  } catch (e) { /* 无缓存 */ }
  const need = missing.filter((ch) => !cache.glyphs[ch]);
  if (need.length) {
    setStatus(`正在用 ${font} 生成 ${need.length} 个字形…`);
    let extra = null;
    await core.executeAsModal(async () => { extra = await ps.buildAtlas(need, font, ATLAS_EM); }, { commandName: "胶片翻拍助手：准备中文字体" });
    for (const ch of need) if (extra.glyphs[ch]) cache.glyphs[ch] = extra.glyphs[ch];
    try {
      const dir = await fs.getDataFolder();
      const out = { em: ATLAS_EM, font, glyphs: {} };
      for (const k in cache.glyphs) { const g = cache.glyphs[k]; out.glyphs[k] = Object.assign({}, g, { a: b64encode(g.a) }); }
      const f = await dir.createFile(fallbackFile(font), { overwrite: true });
      await f.write(JSON.stringify(out));
    } catch (e) { /* 缓存失败不影响使用 */ }
  }
  for (const ch of missing) if (cache.glyphs[ch]) atlas.glyphs[ch] = cache.glyphs[ch];
}

// ---------- 拍摄日期：优先读 RAW/JPEG 里的 EXIF 时间，没有则用文件修改日期 ----------
async function fileDate(entry) {
  try {
    const ab = await entry.read({ format: uxp.storage.formats.binary });
    const u8 = new Uint8Array(ab, 0, Math.min(ab.byteLength, 4 * 1024 * 1024));
    let s = "";
    for (let i = 0; i < u8.length; i += 8192) s += String.fromCharCode.apply(null, u8.subarray(i, i + 8192));
    const mm = s.match(/((?:19|20)\d\d):([01]\d):([0-3]\d) [0-2]\d:[0-5]\d:[0-5]\d/);
    if (mm) return { y: +mm[1], m: +mm[2], d: +mm[3] };
  } catch (e) { /* 读不到就用修改日期 */ }
  try {
    const md = await entry.getMetadata();
    const d = new Date(md.dateModified);
    if (!isNaN(d)) return { y: d.getFullYear(), m: d.getMonth() + 1, d: d.getDate() };
  } catch (e) { /* ignore */ }
  const d = new Date();
  return { y: d.getFullYear(), m: d.getMonth() + 1, d: d.getDate() };
}
const p2 = (n) => String(n).padStart(2, "0");
async function rollDateText(files) {
  if (!files.length) return "";
  const a = await fileDate(files[0]);
  const b = files.length > 1 ? await fileDate(files[files.length - 1]) : a;
  const fa = `${a.y}.${p2(a.m)}.${p2(a.d)}`;
  if (a.y === b.y && a.m === b.m && a.d === b.d) return fa;
  const [lo, hi] = (a.y * 10000 + a.m * 100 + a.d) <= (b.y * 10000 + b.m * 100 + b.d) ? [a, b] : [b, a];
  const flo = `${lo.y}.${p2(lo.m)}.${p2(lo.d)}`;
  return lo.y === hi.y ? `${flo} - ${p2(hi.m)}.${p2(hi.d)}` : `${flo} - ${hi.y}.${p2(hi.m)}.${p2(hi.d)}`;
}

async function writeContactSheet(rollFolder, outFolder, thumbs, settings, files) {
  const n = Math.min(thumbs.length, SHEET_MAX);
  const name = filmEdgeName(settings);
  const line1 = (name ? name + "  ·  " : "") + n + " FRAMES";
  const line2 = await rollDateText(files.slice(0, Math.max(1, n)));
  const { buf } = FF.composeSheet(thumbs.slice(0, n), state.atlas, name, line1, line2,
    FF.sheetStyle(settings.sheetBg, settings.sheetText), { signature: EDITION.signature });
  const fileName = safeName(rollFolder.name) + "_整卷预览.jpg";
  const entry = await outFolder.createFile(fileName, { overwrite: true });
  await core.executeAsModal(() => ps.saveRgbAsJpeg(buf, entry, 12, "整卷预览"), { commandName: "胶片翻拍助手：整卷预览" });
  log(`整卷预览图已生成：${OUT_DIR}\\${fileName}`, "ok");
}

async function runRoll(rollFolder, settings, rollIdx, rollCount) {
  const files = await listImages(rollFolder);
  if (!files.length) { log(`卷「${rollFolder.name}」里没有可处理的图片`, "warn"); return null; }
  const outFolder = await getOrCreateFolder(rollFolder, OUT_DIR);
  const jpgFolder = await getOrCreateFolder(outFolder, JPG_DIR);
  try { await rememberFolder(outFolder.nativePath, outFolder); } catch (e) { /* ignore */ }

  const frameFolder = settings.frame ? await getOrCreateFolder(outFolder, FRAME_DIR) : null;
  const thumbs = [];
  if (settings.frame && files.length > SHEET_MAX) log(`本卷 ${files.length} 张，整卷预览图只收录前 ${SHEET_MAX} 张`, "warn");
  const report = { roll: rollFolder.name, filmStock: filmStockOf(settings), created: new Date().toISOString(), settings, frames: [] };
  log(`▶ 第 ${rollIdx + 1}/${rollCount} 卷「${rollFolder.name}」：${files.length} 张`);
  const rollTag = `卷 ${rollIdx + 1}/${rollCount}`;

  // 整卷统一：先分析整卷，算出统一的定标参数
  let rollLv = null;
  const pre = {};
  if (settings.mode === "roll") {
    for (let i = 0; i < files.length && !state.stop; i++) {
      setStatus(`${rollTag} · 分析 ${i + 1}/${files.length} · ${files[i].name}`);
      setProgress(i, files.length * 2);
      try { pre[files[i].name] = await processFile(files[i], settings, outFolder, jpgFolder, null, { analyzeOnly: true }); }
      catch (e) { log(`✗ 分析 ${files[i].name}：${e.message || e}`, "error"); }
    }
    rollLv = computeRollLevels(Object.values(pre).filter(Boolean));
    if (rollLv) {
      report.rollLevels = rollLv.summary;
      log(`整卷统一定标：密度范围 ${rollLv.summary.range.toFixed(3)}，γ ${rollLv.summary.gamma.toFixed(2)}（${rollLv.summary.frames} 张参与）`);
    } else {
      log("没有足够的片基信息，改为逐张定标", "warn");
    }
  }

  const base = settings.mode === "roll" ? files.length : 0;
  const total = base + files.length;
  for (let i = 0; i < files.length; i++) {
    if (state.stop) { log("已停止", "warn"); break; }
    const entry = files[i];
    const stem = outputStem(rollFolder.name, entry, i, settings);
    setStatus(`${rollTag} · ${i + 1}/${files.length} · ${entry.name}`);
    setProgress(base + i, total);
    const frame = { source: entry.name, jpeg: stem + ".jpg", psd: settings.psd ? stem + ".psd" : null };
    try {
      const p = pre[entry.name];
      const levels = rollLv && p ? rollLv.perFrame(p) : null;
      const opt = levels ? { levels } : {};
      if (frameFolder) opt.frame = { no: i + 1, folder: frameFolder, wantThumb: i < SHEET_MAX };
      const info = await processFile(entry, settings, outFolder, jpgFolder, stem, opt);
      if (info.thumb) { thumbs[i] = info.thumb; delete info.thumb; }
      Object.assign(frame, info);
      frame.needsReview = !info.geometryApplied || info.confidence < 0.6;
      const tag = frame.needsReview ? "⚠ " : "✓ ";
      const geo = frame.geometryApplied ? `调平 ${frame.angle.toFixed(2)}°  比例 ${frame.ratio}` : "未裁切";
      log(`${tag}${entry.name} → ${stem}  ${geo}${frame.warnings.length ? "  （" + frame.warnings.join("；") + "）" : ""}`, frame.needsReview ? "warn" : "");
    } catch (e) {
      frame.error = String(e && e.message ? e.message : e);
      log(`✗ ${entry.name}：${frame.error}`, "error");
    }
    report.frames.push(frame);
    setProgress(base + i + 1, total);
  }

  if (frameFolder && !state.stop) {
    const count = Math.min(files.length, SHEET_MAX);
    for (let i = 0; i < count; i++) if (!thumbs[i]) thumbs[i] = null;
    try { await writeContactSheet(rollFolder, outFolder, thumbs.slice(0, count), settings, files.slice(0, count)); }
    catch (e) { log("✗ 整卷预览图生成失败：" + (e.message || e), "error"); }
  }

  await writeJson(outFolder, "roll.json", report);
  const bad = report.frames.filter((f) => f.needsReview || f.error).length;
  log(`■ 卷「${rollFolder.name}」完成：${report.frames.length} 张，需检查 ${bad} 张。输出在 ${OUT_DIR} 文件夹`, bad ? "warn" : "ok");
  return report;
}

function median(arr) {
  const a = arr.filter((x) => Number.isFinite(x)).sort((x, y) => x - y);
  if (!a.length) return null;
  const m = a.length >> 1;
  return a.length % 2 ? a[m] : (a[m - 1] + a[m]) / 2;
}

function computeRollLevels(frames) {
  const ok = frames.filter((f) => f.levels && f.stats && f.stats.filmBase && f.stats.filmBase > 0.3);
  if (ok.length < 2) return null;
  const range = median(ok.map((f) => (f.levels.inWhite - f.levels.inBlack) / (255 * f.stats.filmBase)));
  const gamma = median(ok.map((f) => f.levels.gamma));
  return {
    summary: { range, gamma, frames: ok.length },
    perFrame(f) {
      if (!f.stats || !f.stats.filmBase) return null;
      const base = f.stats.filmBase;
      const inBlack = Math.max(0, Math.min(230, Math.round(255 * (1 - base)) + 1));
      const inWhite = Math.max(inBlack + 20, Math.min(255, Math.round(inBlack + 255 * base * range)));
      return { inBlack, inWhite, gamma: Math.round(gamma * 100) / 100 };
    }
  };
}

// ======================== 按钮动作 ========================
async function pickRoll() {
  const f = await fs.getFolder();
  if (!f) return;
  state.rollFolder = f;
  $("rollPath").textContent = f.nativePath;
  try { localStorage.setItem("film135roll.lastRoll", await fs.createPersistentToken(f)); } catch (e) { /* ignore */ }
  const rolls = await rollsFromFolder(f, $("optSubRolls").checked);
  let total = 0;
  for (const r of rolls) total += (await listImages(r)).length;
  setStatus(`${rolls.length} 卷，共 ${total} 张图片`);
}

async function restoreLastRoll() {
  try {
    const t = localStorage.getItem("film135roll.lastRoll");
    if (!t) return;
    const f = await fs.getEntryForPersistentToken(t);
    if (f) { state.rollFolder = f; $("rollPath").textContent = f.nativePath; }
  } catch (e) { /* 授权过期 */ }
}

async function startBatch() {
  if (state.running) return;
  if (!state.rollFolder) { setStatus("请先选择卷文件夹", true); return; }
  const settings = readSettings();
  saveSettings();
  state.running = true; state.stop = false;
  toggleRunning(true);
  try {
    const rolls = await rollsFromFolder(state.rollFolder, settings.subRolls);
    if (!rolls.length) { setStatus("没有找到可处理的图片", true); return; }
    if (settings.frame) await ensureGlyphs([filmEdgeName(settings), EDITION.signature || ""]);
    for (let r = 0; r < rolls.length && !state.stop; r++) await runRoll(rolls[r], settings, r, rolls.length);
    setStatus(state.stop ? "已停止" : "全部完成");
  } catch (e) {
    setStatus("出错：" + (e.message || e), true);
    log("✗ " + (e.message || e), "error");
  } finally {
    state.running = false;
    toggleRunning(false);
  }
}

function setDisabled(id, on) {
  const el = $(id);
  if (!el) return;
  if (on) el.setAttribute("disabled", "true"); else el.removeAttribute("disabled");
}
function toggleRunning(on) {
  setDisabled("btnStart", on);
  setDisabled("btnStop", !on);
}

async function withActiveDoc(label, fn) {
  if (state.running) { setStatus("批量处理中，请稍候", true); return; }
  const doc = app.activeDocument;
  if (!doc) { setStatus("请先打开一张照片", true); return; }
  try {
    await core.executeAsModal(() => fn(doc), { commandName: "胶片翻拍助手：" + label });
  } catch (e) {
    setStatus(label + "失败：" + (e.message || e), true);
  }
}

async function processCurrent() {
  const settings = readSettings();
  saveSettings();
  await withActiveDoc("处理当前文档", async (doc) => {
    const info = await processDocument(doc, settings);
    const msg = info.geometryApplied ? `完成：调平 ${info.angle.toFixed(2)}°，比例 ${info.ratio}` : "已反色；未能自动裁切，请手动框选后点“按选区裁切”";
    setStatus(msg + (info.warnings.length ? "（" + info.warnings.join("；") + "）" : ""), !info.geometryApplied);
  });
}

async function setAdjVisible(doc, names, visible) {
  for (const n of names) { const l = ps.findLayer(doc, n); if (l) l.visible = visible; }
}

async function redetectGeometry() {
  const settings = readSettings();
  await withActiveDoc("重新检测调平/裁切", async (doc) => {
    const base = ps.findLayer(doc, LAYER.base);
    if (!base) throw new Error("没有找到“负片”图层");
    await ps.revealAll();
    const adj = [LAYER.bw, LAYER.invert, LAYER.levels];
    await setAdjVisible(doc, adj, false);
    try {
      const px = await ps.readComposite(doc, ANALYSIS_SIZE);
      const res = FA.analyze(px);
      if (!res.frameFound || res.confidence < 0.5) throw new Error("仍未识别到画幅：" + res.warnings.join("；"));
      await ps.selectLayer(base);
      await ps.rotateActiveLayer(res.angle);
      await ps.cropDoc(doc, docRectFromAnalysis(res, px, settings));
      setStatus(`已重新调平 ${res.angle.toFixed(2)}° 并裁切`);
    } finally {
      await setAdjVisible(doc, adj, true);
    }
  });
}

async function reAutoLevels() {
  const settings = readSettings();
  await withActiveDoc("重新自动定标", async (doc) => {
    const lvLayer = ps.findLayer(doc, LAYER.levels);
    if (!lvLayer) throw new Error("没有找到“反色定标”图层");
    const hide = [LAYER.invert, LAYER.levels];
    await setAdjVisible(doc, hide, false);
    let res;
    try { res = FA.analyze(await ps.readComposite(doc, ANALYSIS_SIZE), { statsOnly: true }); }
    finally { await setAdjVisible(doc, hide, true); }
    const lv = FA.computeLevels(res.stats, { clip: settings.clip, autoGamma: settings.autoGamma });
    await ps.setAdjustment(lvLayer, ps.levelsDesc(lv), levelsName(lv));
    setStatus(`定标：黑 ${lv.inBlack} / 白 ${lv.inWhite} / γ ${lv.gamma}`);
  });
}

async function rotateBase(deg) {
  await withActiveDoc("微调角度", async (doc) => {
    const base = ps.findLayer(doc, LAYER.base) || doc.layers[doc.layers.length - 1];
    await ps.selectLayer(base);
    await ps.rotateActiveLayer(deg);
    setStatus(`负片已旋转 ${deg > 0 ? "+" : ""}${deg}°`);
  });
}

async function cropToSelection() {
  await withActiveDoc("按选区裁切", async (doc) => {
    const b = await ps.getSelectionBounds();
    if (!b) throw new Error("请先用矩形选框框出画幅");
    await ps.cropDoc(doc, b);
    await ps.deselect();
    setStatus("已按选区裁切");
  });
}

async function saveCurrent() {
  if (state.running) { setStatus("批量处理中，请稍候", true); return; }
  const settings = readSettings();
  const doc = app.activeDocument;
  if (!doc) { setStatus("请先打开一张照片", true); return; }
  // 文件夹授权/选择必须在 modal 之外完成
  let psdPath = null;
  try { psdPath = doc.path; } catch (e) { /* 未保存 */ }
  const isPsd = !!psdPath && extOf(psdPath) === "psd";
  let targetFolder = null;
  try {
    if (!isPsd) {
      setStatus("请选择保存 PSD 的文件夹");
      targetFolder = await fs.getFolder();
      if (!targetFolder) { setStatus("已取消"); return; }
    } else {
      targetFolder = await folderForNativePath(dirOfPath(psdPath));
      if (!targetFolder) { setStatus("已取消"); return; }
    }
    // 胶片画框：序号取 roll.json 里的顺序（找不到则不显示序号）
    let frameNo = null, frameFolder = null;
    if (settings.frame) {
      await ensureGlyphs([filmEdgeName(settings), EDITION.signature || ""]);
      if (isPsd) {
        const rep = await readJson(targetFolder, "roll.json");
        const nm = psdPath.replace(/^.*[\\/]/, "");
        const idx = rep && rep.frames ? rep.frames.findIndex((f) => f.psd === nm) : -1;
        if (idx >= 0) frameNo = idx + 1;
      }
      frameFolder = await getOrCreateFolder(targetFolder, FRAME_DIR);
    }
    await core.executeAsModal(async () => {
      let stem;
      if (isPsd) {
        await doc.save();
        stem = stemOf(psdPath.replace(/^.*[\\/]/, ""));
      } else {
        stem = stemOf(doc.title);
        const f = await targetFolder.createFile(stem + ".psd", { overwrite: true });
        await ps.savePsd(doc, f, !settings.psdCompress);
      }
      {
        const jpgFolder = await getOrCreateFolder(targetFolder, JPG_DIR);
        const jpgEntry = await jpgFolder.createFile(stem + ".jpg", { overwrite: true });
        let full = null;
        await ps.exportJpeg(doc, jpgEntry, settings.jpegQ, frameFolder ? async (dup) => { full = await ps.readFullRGB(dup); } : null);
        if (frameFolder && full) {
          const buf = FF.composeFrame(full, state.atlas, frameNo, filmEdgeName(settings), null, { signature: EDITION.signature });
          full = null;
          const fEntry = await frameFolder.createFile(stem + ".jpg", { overwrite: true });
          await ps.saveRgbAsJpeg(buf, fEntry, settings.jpegQ, stem + "_画框");
        }
      }
    }, { commandName: "胶片翻拍助手：保存并导出" });
    setStatus("已保存 PSD 并导出 JPEG" + (frameFolder ? "（含胶片画框）" : ""));
  } catch (e) {
    setStatus("保存失败：" + (e.message || e), true);
  }
}

// ======================== 胶卷厂商 / 型号：可输入也可选择，可存为预设 ========================
const CUSTOM_KEY = "film135roll.customFilms";
function loadCustomFilms() {
  try { const a = JSON.parse(localStorage.getItem(CUSTOM_KEY) || "[]"); return Array.isArray(a) ? a : []; } catch (e) { return []; }
}
function saveCustomFilms(list) {
  try { localStorage.setItem(CUSTOM_KEY, JSON.stringify(list)); } catch (e) { /* ignore */ }
}
const same = (a, b) => String(a || "").trim().toLowerCase() === String(b || "").trim().toLowerCase();

// 内置列表 + 自定义预设合并；自定义型号排在该厂商最前面
function allStocks() {
  const out = FILM_STOCKS.map((f) => ({ maker: f.maker, cn: f.cn, models: f.models.slice(), custom: new Set(), customMaker: false }));
  for (const c of loadCustomFilms()) {
    let f = out.find((x) => same(x.maker, c.maker));
    if (!f) { f = { maker: c.maker, cn: "", models: [], custom: new Set(), customMaker: true }; out.push(f); }
    if (c.model && !f.models.some((md) => same(md, c.model))) { f.models.unshift(c.model); f.custom.add(c.model); }
  }
  // 自定义厂商的自定义型号保持添加顺序
  for (const f of out) if (f.customMaker) f.models.reverse();
  return out;
}
function makerEntry(name) {
  const n = (name || "").trim();
  if (!n) return null;
  return allStocks().find((f) => same(f.maker, n) || (f.cn && f.cn === n));
}

// ======================== 整卷预览图：底色 / 文字颜色 ========================
const SHEET_BG_LABEL = { dark: "深色", light: "浅色", white: "纯白" };
const SHEET_TEXT_LABEL = { orange: "橙色", black: "黑色" };
const sheetPick = { bg: "dark", text: "orange" };   // text 记住用户选择；深色底上实际总是橙色
function sheetTextEffective() { return sheetPick.bg === "dark" ? "orange" : sheetPick.text; }
function updateSheetPickers() {
  const a = $("txtSheetBg"), b = $("txtSheetText");
  if (a) a.textContent = "底色 · " + SHEET_BG_LABEL[sheetPick.bg];
  if (b) b.textContent = "文字 · " + SHEET_TEXT_LABEL[sheetTextEffective()];
}
let sheetListFor = null;
function hideSheetList() { const l = $("sheetList"); if (l) l.style.display = "none"; sheetListFor = null; }
function showSheetList(which) {
  const list = $("sheetList");
  if (!list) return;
  if (sheetListFor === which && list.style.display === "block") { hideSheetList(); return; }
  hideFilmList();
  list.innerHTML = "";
  const items = which === "bg"
    ? Object.keys(SHEET_BG_LABEL).map((k) => ({ key: k, text: SHEET_BG_LABEL[k] }))
    : Object.keys(SHEET_TEXT_LABEL).map((k) => ({ key: k, text: SHEET_TEXT_LABEL[k],
        disabled: sheetPick.bg === "dark" && k === "black" }));
  const cur = which === "bg" ? sheetPick.bg : sheetTextEffective();
  for (const it of items) {
    const row = document.createElement("div");
    row.className = "combo-item" + (it.disabled ? " disabled" : "") + (it.key === cur ? " current" : "");
    const label = document.createElement("div");
    label.className = "combo-label";
    label.textContent = (it.key === cur ? "✓ " : "") + it.text + (it.disabled ? "（深色底上看不见，请选浅色或纯白）" : "");
    if (!it.disabled) {
      label.addEventListener("click", () => {
        if (which === "bg") sheetPick.bg = it.key; else sheetPick.text = it.key;
        hideSheetList();
        updateSheetPickers();
        saveSettings();
      });
    }
    row.appendChild(label);
    list.appendChild(row);
  }
  sheetListFor = which;
  list.style.display = "block";
}

// 两个输入框共用一个下拉列表（在文档流中展开，不会被其它控件遮挡）
const comboState = { active: null, hideTimer: null };
function hideFilmList() { const l = $("filmList"); if (l) l.style.display = "none"; comboState.active = null; }
function setupCombo(btnId, inputId, getItems, onPick) {
  const input = $(inputId), btn = $(btnId), list = $("filmList");
  if (!input || !btn || !list) return;
  const render = (filter) => {
    const f = (filter || "").trim().toLowerCase();
    const items = getItems().filter((it) => !f || it.value.toLowerCase().indexOf(f) >= 0 || (it.hint && it.hint.indexOf(filter.trim()) >= 0));
    list.innerHTML = "";
    for (const it of items) {
      const row = document.createElement("div");
      row.className = "combo-item";
      const label = document.createElement("div");
      label.className = "combo-label";
      label.textContent = (it.custom ? "★ " : "") + (it.hint ? it.value + "  " + it.hint : it.value);
      label.addEventListener("click", () => {
        clearTimeout(comboState.hideTimer);
        input.value = it.value;
        if (it.maker && $("optFilmMaker") && !$("optFilmMaker").value.trim()) { $("optFilmMaker").value = it.maker; lastMaker = it.maker; }
        hideFilmList();
        onPick && onPick(it.value);
        updatePresetButton();
      });
      row.appendChild(label);
      if (it.onDelete) {
        const del = document.createElement("div");
        del.className = "combo-del";
        del.textContent = "✕";
        del.addEventListener("click", (ev) => {
          if (ev && ev.stopPropagation) ev.stopPropagation();
          clearTimeout(comboState.hideTimer);
          it.onDelete();
          render(filter);
          updatePresetButton();
        });
        row.appendChild(del);
      }
      list.appendChild(row);
    }
    comboState.active = inputId;
    list.style.display = items.length ? "block" : "none";
  };
  btn.addEventListener("click", () => {
    clearTimeout(comboState.hideTimer);
    if (comboState.active === inputId && list.style.display === "block") { hideFilmList(); return; }
    hideSheetList();
    render("");
  });
  input.addEventListener("input", () => { clearTimeout(comboState.hideTimer); render(input.value); saveSettings(); updatePresetButton(); });
  input.addEventListener("blur", () => { comboState.hideTimer = setTimeout(() => { if (comboState.active === inputId) hideFilmList(); saveSettings(); }, 300); });
}

function deleteCustom(maker, model) {
  saveCustomFilms(loadCustomFilms().filter((c) => !(same(c.maker, maker) && (model == null || same(c.model, model)))));
  setStatus(model == null ? `已删除自定义厂商：${maker}` : `已删除预设：${[maker, model].filter(Boolean).join(" ")}`);
}

// 判断当前输入里有没有“列表里没有的”厂商 / 型号
function newInputs() {
  const maker = ($("optFilmMaker").value || "").trim();
  const model = ($("optFilmModel").value || "").trim();
  const mk = makerEntry(maker);
  const newMaker = !!maker && !mk;
  const newModel = !!model && !(mk ? mk.models.some((md) => same(md, model)) : (!maker && allStocks().some((f) => f.models.some((md) => same(md, model)))));
  return { maker: mk ? mk.maker : maker, model, newMaker, newModel };
}
// 只有输入了新的厂商或型号时才显示“存为预设”
function updatePresetButton() {
  const row = $("rowPreset");
  if (!row) return;
  const n = newInputs();
  row.style.display = n.newMaker || n.newModel ? "flex" : "none";
}
// 输入了新厂商就存厂商，输入了新型号就存型号
function savePreset() {
  const n = newInputs();
  if (!n.newMaker && !n.newModel) { updatePresetButton(); return; }
  const list = loadCustomFilms();
  list.push({ maker: n.maker, model: n.newModel ? n.model : "" });
  saveCustomFilms(list);
  if (n.maker) { $("optFilmMaker").value = n.maker; lastMaker = n.maker; }
  saveSettings();
  const what = [n.newMaker ? "厂商 " + n.maker : "", n.newModel ? "型号 " + n.model : ""].filter(Boolean).join("、");
  setStatus(`已存为预设：${what}（在 ▼ 列表中带 ★）`);
  updatePresetButton();
}

// 厂商变了：型号切换为该厂商列表中的第一个
let lastMaker = null;
function onMakerChanged() {
  const mk = makerEntry($("optFilmMaker").value);
  const key = mk ? mk.maker : null;
  if (key && key !== lastMaker && mk.models.length) {
    const cur = $("optFilmModel").value.trim().toLowerCase();
    if (lastMaker !== null || !mk.models.some((x) => x.toLowerCase() === cur)) $("optFilmModel").value = mk.models[0];
  }
  if (key) lastMaker = key;
  saveSettings();
  updatePresetButton();
}
function initFilmCombos() {
  lastMaker = (makerEntry($("optFilmMaker").value) || {}).maker || null;
  setupCombo("btnMakerList", "optFilmMaker",
    () => allStocks().map((f) => ({
      value: f.maker, hint: f.cn, custom: f.customMaker,
      onDelete: f.customMaker ? () => deleteCustom(f.maker, null) : null
    })),
    () => { onMakerChanged(); });
  // 手动输入的厂商名与列表完全一致时，同样切换型号
  bind("optFilmMaker", "input", () => { if (makerEntry($("optFilmMaker").value)) onMakerChanged(); });
  setupCombo("btnModelList", "optFilmModel",
    () => {
      const mk = makerEntry($("optFilmMaker").value);
      const src = mk ? [mk] : allStocks();
      const out = [];
      for (const f of src) for (const md of f.models) {
        const isCustom = f.custom.has(md);
        out.push({
          value: md, hint: mk ? "" : f.maker, maker: mk ? null : f.maker, custom: isCustom,
          onDelete: isCustom ? () => deleteCustom(f.maker, md) : null
        });
      }
      return out;
    },
    () => { saveSettings(); });
  bind("btnSavePreset", "click", savePreset);
  updatePresetButton();
}

// ======================== 初始化 ========================
function bind(id, ev, fn) { const el = $(id); if (el) el.addEventListener(ev, fn); }

function init() {
  const s = loadSettings();
  applySettingsToUI(s);
  document.querySelectorAll(".section-title").forEach((t) => {
    t.addEventListener("click", () => t.parentNode.classList.toggle("collapsed"));
  });
  restoreLastRoll();
  toggleRunning(false);

  bind("btnPick", "click", pickRoll);
  bind("btnStart", "click", startBatch);
  bind("btnStop", "click", () => { state.stop = true; setStatus("正在停止（当前这张处理完后停止）…"); });
  bind("btnProcessCurrent", "click", processCurrent);
  bind("btnRedetect", "click", redetectGeometry);
  bind("btnRevealAll", "click", () => withActiveDoc("显示全部", () => ps.revealAll()));
  bind("btnCropSel", "click", cropToSelection);
  bind("btnRotM05", "click", () => rotateBase(-0.5));
  bind("btnRotM01", "click", () => rotateBase(-0.1));
  bind("btnRotP01", "click", () => rotateBase(0.1));
  bind("btnRotP05", "click", () => rotateBase(0.5));
  bind("btnCanvasCCW", "click", () => withActiveDoc("旋转画布", () => ps.rotateCanvas(-90)));
  bind("btnCanvasCW", "click", () => withActiveDoc("旋转画布", () => ps.rotateCanvas(90)));
  bind("btnReLevels", "click", reAutoLevels);
  bind("btnSave", "click", saveCurrent);
  bind("btnClearLog", "click", () => { $("log").innerHTML = ""; });
  initFilmCombos();
  for (const [id, which] of [["btnSheetBg", "bg"], ["txtSheetBg", "bg"], ["btnSheetText", "text"], ["txtSheetText", "text"]]) {
    bind(id, "click", () => showSheetList(which));
  }
  for (const id of ["optSubRolls", "optMode", "optClip", "optAutoGamma", "optInset", "optPsd", "optRename", "optFrame", "optPsdCompress"]) {
    bind(id, "change", () => { updateDependentUI(); saveSettings(); });
  }

  setStatus("就绪");
}

if (typeof document !== "undefined") {
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
}

// 供离线测试使用
if (typeof module !== "undefined") module.exports = { processDocument, computeRollLevels, docRectFromAnalysis, levelsName, listImages };
