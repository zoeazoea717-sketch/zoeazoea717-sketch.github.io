﻿# 胶片翻拍助手 安装程序：安装 Jura Bold 字体 + Photoshop 插件
$ErrorActionPreference = 'Continue'
$root = $PSScriptRoot
$pluginSrc = Join-Path $root 'FilmScanHelper'
$fontSrc = Join-Path $root 'Fonts\Jura-Bold.ttf'

Write-Host ''
Write-Host '========  胶片翻拍助手 · 安装程序  ========' -ForegroundColor Cyan
Write-Host ''
if (-not (Test-Path (Join-Path $pluginSrc 'manifest.json'))) {
  Write-Host "[错误] 找不到插件文件夹：$pluginSrc" -ForegroundColor Red
  Write-Host '请先把压缩包完整解压，再运行 Install.bat。'
  Read-Host '按回车退出'; exit 1
}
$manifest = Get-Content (Join-Path $pluginSrc 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$pluginId = $manifest.id
Write-Host "插件版本：$($manifest.version)"

if (Get-Process Photoshop -ErrorAction SilentlyContinue) {
  Write-Host ''
  Write-Host 'Photoshop 正在运行。请先保存工作并关闭 Photoshop，然后按回车继续。' -ForegroundColor Yellow
  Read-Host | Out-Null
}

# ---------------- 1. 字体 ----------------
Write-Host ''
Write-Host '[1/2] 安装字体 Jura Bold（胶片画框的文字使用此字体）'
$keyM = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts'
$keyU = 'HKCU:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts'
function Test-Jura {
  foreach ($k in $keyM, $keyU) {
    try {
      $p = Get-ItemProperty $k -ErrorAction Stop
      foreach ($prop in $p.PSObject.Properties) {
        if ($prop.Name -like 'Jura Bold*' -or "$($prop.Value)" -like '*Jura-Bold*') { return $true }
      }
    } catch {}
  }
  return $false
}
function Register-FontSession($path) {
  try {
    Add-Type -Namespace FSH -Name Gdi -MemberDefinition '[DllImport("gdi32.dll", CharSet = CharSet.Unicode)] public static extern int AddFontResource(string lpFileName);' -ErrorAction Stop
    [FSH.Gdi]::AddFontResource($path) | Out-Null
  } catch {}
}
if (Test-Jura) {
  Write-Host '  已安装，跳过。' -ForegroundColor Green
} elseif (-not (Test-Path $fontSrc)) {
  Write-Host "  [警告] 安装包里缺少字体文件：$fontSrc" -ForegroundColor Yellow
} else {
  $ok = $false
  try {
    $dest = Join-Path $env:windir 'Fonts\Jura-Bold.ttf'
    Copy-Item $fontSrc $dest -Force -ErrorAction Stop
    New-ItemProperty -Path $keyM -Name 'Jura Bold (TrueType)' -Value 'Jura-Bold.ttf' -PropertyType String -Force -ErrorAction Stop | Out-Null
    Register-FontSession $dest
    $ok = $true
    Write-Host '  已为所有用户安装。' -ForegroundColor Green
  } catch {
    # 退路：只为当前用户安装
    try {
      $dir = Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Fonts'
      New-Item -ItemType Directory -Path $dir -Force | Out-Null
      $dest = Join-Path $dir 'Jura-Bold.ttf'
      Copy-Item $fontSrc $dest -Force -ErrorAction Stop
      New-ItemProperty -Path $keyU -Name 'Jura Bold (TrueType)' -Value $dest -PropertyType String -Force -ErrorAction Stop | Out-Null
      Register-FontSession $dest
      $ok = $true
      Write-Host '  已为当前用户安装。' -ForegroundColor Green
    } catch {}
  }
  if (-not $ok) { Write-Host '  [警告] 字体安装失败，可以双击 Fonts\Jura-Bold.ttf 手动点“安装”。' -ForegroundColor Yellow }
}

# ---------------- 2. 插件 ----------------
Write-Host ''
Write-Host '[2/2] 安装 Photoshop 插件'
$dirs = New-Object System.Collections.Generic.List[string]
function Add-Dir($d) { if ($d -and (Test-Path (Join-Path $d 'Photoshop.exe')) -and -not $dirs.Contains($d)) { $dirs.Add($d) } }
Write-Host '  正在查找 Photoshop ...'
foreach ($k in 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\Photoshop.exe','HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\Photoshop.exe') {
  try { $p = (Get-ItemProperty $k -ErrorAction Stop).'(default)'; if ($p) { Add-Dir (Split-Path ($p.Trim('"'))) } } catch {}
}
try { Get-ChildItem 'HKLM:\SOFTWARE\Adobe\Photoshop' -ErrorAction Stop | ForEach-Object { try { Add-Dir ((Get-ItemProperty $_.PSPath -ErrorAction Stop).ApplicationPath.TrimEnd('\')) } catch {} } } catch {}
Get-Process Photoshop -ErrorAction SilentlyContinue | ForEach-Object { try { Add-Dir (Split-Path $_.Path) } catch {} }
try {
  $sh = New-Object -ComObject WScript.Shell
  foreach ($r in @("$env:ProgramData\Microsoft\Windows\Start Menu", "$env:APPDATA\Microsoft\Windows\Start Menu", [Environment]::GetFolderPath('Desktop'), "$env:PUBLIC\Desktop")) {
    if (Test-Path $r) { Get-ChildItem $r -Recurse -Filter '*.lnk' -ErrorAction SilentlyContinue | Where-Object { $_.Name -match 'Photoshop' } | ForEach-Object { try { $t = $sh.CreateShortcut($_.FullName).TargetPath; if ($t -match 'Photoshop\.exe$') { Add-Dir (Split-Path $t) } } catch {} } }
  }
} catch {}
if ($dirs.Count -eq 0) {
  Write-Host '  注册表里没有记录，正在搜索各个磁盘（可能需要一两分钟）...'
  Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Free -ne $null } | ForEach-Object {
    Get-ChildItem $_.Root -Filter 'Photoshop.exe' -Recurse -Depth 4 -ErrorAction SilentlyContinue | ForEach-Object { Add-Dir $_.DirectoryName }
  }
}
if ($dirs.Count -eq 0) {
  Write-Host ''
  Write-Host '  没有自动找到 Photoshop。' -ForegroundColor Yellow
  Write-Host '  请右键桌面上的 Photoshop 图标 → “打开文件所在的位置”，把地址栏里的路径粘贴到这里：'
  $d = (Read-Host '  路径').Trim().Trim('"')
  if ($d -match 'Photoshop\.exe$') { $d = Split-Path $d }
  Add-Dir $d
  if ($dirs.Count -eq 0) { Write-Host "  [错误] 该文件夹里没有 Photoshop.exe：$d" -ForegroundColor Red; Read-Host '按回车退出'; exit 1 }
}

$ok = 0
foreach ($d in $dirs) {
  Write-Host "  Photoshop：$d"
  $plug = Join-Path $d 'Plug-ins'
  if (-not (Test-Path $plug)) { New-Item -ItemType Directory -Path $plug -Force | Out-Null }
  # 移除同一插件的旧版本（不论文件夹叫什么）
  Get-ChildItem $plug -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    $mf = Join-Path $_.FullName 'manifest.json'
    if (Test-Path $mf) {
      try {
        $j = Get-Content $mf -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($j.id -eq $pluginId) { Remove-Item $_.FullName -Recurse -Force -ErrorAction Stop; Write-Host "  已移除旧版本：$($_.Name)" }
      } catch {}
    }
  }
  $dest = Join-Path $plug 'FilmScanHelper'
  try {
    Copy-Item $pluginSrc $dest -Recurse -Force -ErrorAction Stop
    Write-Host "  已安装到：$dest" -ForegroundColor Green
    $ok++
  } catch {
    Write-Host "  [错误] 无法写入 $dest ：$($_.Exception.Message)" -ForegroundColor Red
  }
}

# 通过 Creative Cloud（.ccx）装过的旧版本会和本插件冲突，提示卸载
foreach ($ext in @("$env:CommonProgramFiles\Adobe\UXP\Plugins\External", "$env:APPDATA\Adobe\UXP\Plugins\External")) {
  if (Test-Path $ext) {
    Get-ChildItem $ext -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like "$pluginId*" } | ForEach-Object {
      Write-Host "  [提示] 检测到通过 Creative Cloud 安装的旧版本：$($_.FullName)" -ForegroundColor Yellow
      Write-Host '         请在 Creative Cloud 的「增效工具 / 管理增效工具」里卸载它，避免两个版本冲突。' -ForegroundColor Yellow
    }
  }
}

Write-Host ''
if ($ok -gt 0) {
  Write-Host '安装完成！请打开 Photoshop，菜单：增效工具 → 胶片翻拍助手' -ForegroundColor Green
} else {
  Write-Host '插件没有安装成功，请截图这个窗口反馈。' -ForegroundColor Red
}
Read-Host '按回车关闭'
